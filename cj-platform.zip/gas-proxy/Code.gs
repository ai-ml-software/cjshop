/**
 * CJ GLOBALLY — Google Apps Script Proxy for CJDropshipping API
 * Paste this whole file into your Apps Script project (replacing Code.gs),
 * then Deploy > Manage deployments > Edit > New version > Deploy.
 *
 * Why this exists:
 *  - Keeps the CJ API key server-side (never shipped to the browser).
 *  - Caches the access token so pages never re-auth.
 *  - Client sends POST bodies as text/plain so the browser never issues a
 *    CORS preflight (OPTIONS) request — Apps Script web apps don't answer
 *    preflights, so a JSON content-type on the client causes "Failed to
 *    fetch" even though the deployment itself is fine.
 *
 * Real CJ point costs (per developers.cjdropshipping.cn/en/api/api2/standard/points.html
 * — a prior version of this file's comments claimed /product/list was free,
 * which was wrong and led to a rate-limiting incident):
 *   /product/list        50 pts/call   /product/listV2  50 pts/call (same cost — no
 *   /product/query       10 pts/call   savings from preferring one over the other)
 *   /product/variant/query  10 pts/call
 *   /product/getCategory, /product/productComments, /product/queryVideosByProductId — free
 * Daily allowance = 50,000 base + (last-3-months order volume × 100), resets at
 * 00:00 UTC, and also trickles back continuously at (daily total / 1440) points
 * per minute. Every CacheService TTL below exists to avoid re-spending points on
 * data that hasn't changed — treat lowering a TTL as a real cost, not just a
 * "freshness" knob.
 */

// ──────────────────────────────────────────────────────────────
// CREDENTIALS (server-side only — never exposed to the browser)
// ──────────────────────────────────────────────────────────────
const CJ_API_BASE = 'https://developers.cjdropshipping.com/api2.0/v1';
const CJ_EMAIL = 'usamaestonia@gmail.com';
const CJ_API_KEY = 'CJ5580877@api@fbfc1eb42a3244a5969aa554bd5743c4'; // rotate in CJ dashboard if ever shared

// ──────────────────────────────────────────────────────────────
// AUTHENTICATION
// ──────────────────────────────────────────────────────────────
function getAccessToken_() {
  const props = PropertiesService.getScriptProperties();
  const cachedToken = props.getProperty('cj_access_token');
  const cachedTime = Number(props.getProperty('cj_access_token_time') || 0);
  const now = new Date().getTime();

  if (!cachedToken || (now - cachedTime) > (23 * 60 * 60 * 1000)) {
    const res = UrlFetchApp.fetch(CJ_API_BASE + '/authentication/getAccessToken', {
      method: 'post',
      headers: { 'Content-Type': 'application/json' },
      payload: JSON.stringify({ email: CJ_EMAIL, password: CJ_API_KEY }),
      muteHttpExceptions: true,
    });
    const json = JSON.parse(res.getContentText());
    if (json.result && json.data && json.data.accessToken) {
      props.setProperty('cj_access_token', json.data.accessToken);
      props.setProperty('cj_access_token_time', now.toString());
      return json.data.accessToken;
    }
    throw new Error('Failed to get access token: ' + JSON.stringify(json));
  }
  return cachedToken;
}

// ──────────────────────────────────────────────────────────────
// HTTP ENTRY POINTS
// ──────────────────────────────────────────────────────────────
function doGet(e) { return handleRequest_(e); }
function doPost(e) { return handleRequest_(e); }

function handleRequest_(e) {
  e = e || {};
  try {
    const params = e.parameter || {};
    let payload = {};
    if (e.postData && e.postData.contents) {
      try { payload = JSON.parse(e.postData.contents); } catch (_) { payload = {}; }
    } else {
      payload = params;
    }
    const action = payload.action || params.action || 'ping';

    let result;
    switch (action) {
      case 'categories': result = fetchCategories_(); break;
      case 'homepage_categories': result = fetchHomepageCategories_(); break;
      case 'products': result = fetchProductsByCategory_(payload.categoryId, payload.pageNum || 1, payload.pageSize || 12); break;
      case 'product_detail': result = fetchProductDetail_(payload.pid); break;
      case 'product_videos': result = fetchProductVideos_(payload.pid); break;
      case 'freight': result = calculateFreight_(payload); break;
      case 'create_order': result = createOrder_(payload); break;
      case 'track': result = trackOrder_(payload.trackingNumber || payload.trackNumber); break;
      case 'ping': result = { ok: true, time: new Date().toISOString() }; break;
      default: result = { ok: false, error: 'Unknown action: ' + action };
    }

    return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ──────────────────────────────────────────────────────────────
// LOW-LEVEL CJ CALLERS
// ──────────────────────────────────────────────────────────────
function cjGet_(endpoint, params) {
  const accessToken = getAccessToken_();
  const queryParams = [];
  for (const key in params) {
    if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
      queryParams.push(encodeURIComponent(key) + '=' + encodeURIComponent(params[key]));
    }
  }
  const url = CJ_API_BASE + endpoint + (queryParams.length ? '?' + queryParams.join('&') : '');
  return fetchWithRetry_(url, {
    method: 'get',
    headers: { 'CJ-Access-Token': accessToken },
    muteHttpExceptions: true,
  });
}

function cjPost_(endpoint, body) {
  const accessToken = getAccessToken_();
  return fetchWithRetry_(CJ_API_BASE + endpoint, {
    method: 'post',
    headers: { 'CJ-Access-Token': accessToken, 'Content-Type': 'application/json' },
    payload: JSON.stringify(body || {}),
    muteHttpExceptions: true,
  });
}

// A 429 means CJ rejected the request before doing anything with it, so
// retrying after a short backoff is safe (no risk of double-processing an
// order). Without this, a single rate-limit hit during the homepage's
// category scan permanently looked like "no products in this category"
// until the next full page reload retried it.
function fetchWithRetry_(url, opts) {
  const MAX_ATTEMPTS = 4;
  let json, status;
  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
    const res = UrlFetchApp.fetch(url, opts);
    status = res.getResponseCode();
    try { json = JSON.parse(res.getContentText()); } catch (_) { json = { raw: res.getContentText() }; }
    json._httpStatus = status;
    if (status !== 429 && json.code !== 429) break;
    if (attempt < MAX_ATTEMPTS - 1) Utilities.sleep(1000 * Math.pow(2, attempt)); // 1s, 2s, 4s
  }
  return json;
}

// ──────────────────────────────────────────────────────────────
// CATEGORIES (free endpoint, cached 6h — this list barely changes)
// ──────────────────────────────────────────────────────────────
function fetchCategories_() {
  const cache = CacheService.getScriptCache();
  const cached = cache.get('cj_categories');
  if (cached) return { ok: true, data: JSON.parse(cached) };

  const data = cjGet_('/product/getCategory', {});
  if (!data.result) return { ok: false, error: data.message || 'Failed to fetch categories', data: data };

  cache.put('cj_categories', JSON.stringify(data.data || []), 21600); // 6 hours
  return { ok: true, data: data.data || [] };
}

// ──────────────────────────────────────────────────────────────
// PRODUCTS — /product/list costs 50 pts/call (same as listV2 — there is no
// free product-listing endpoint). Cached 2h per (categoryId, page) so repeat
// visits within that window cost nothing.
// ──────────────────────────────────────────────────────────────
function fetchProductsByCategory_(categoryId, pageNum, pageSize) {
  const cache = CacheService.getScriptCache();
  const cacheKey = 'cj_products_' + categoryId + '_' + pageNum + '_' + pageSize;
  const cached = cache.get(cacheKey);
  if (cached) return { ok: true, data: JSON.parse(cached) };

  const data = cjGet_('/product/list', { categoryId: categoryId, pageNum: pageNum, pageSize: pageSize });
  if (!data.result) return { ok: false, error: data.message || 'Failed to fetch products', data: data };

  const list = (data.data && (data.data.list || data.data.content)) || [];
  cache.put(cacheKey, JSON.stringify(list), 7200); // 2h — each call is 50 pts, don't re-spend it needlessly
  return { ok: true, data: list };
}

// ──────────────────────────────────────────────────────────────
// HOMEPAGE — one cached call that scans every leaf category for in-stock
// products, instead of the browser firing one request per category. That
// per-visitor fan-out (dozens of calls a few hundred ms apart, 50 pts each)
// is what was tripping CJ's rate limit and burning the whole daily point
// budget in a handful of page loads. Cached 6h (CacheService's max TTL) —
// this is the single most expensive operation in the app (N leaf categories
// x 50 pts on a cold cache), so it must run as rarely as possible.
// ──────────────────────────────────────────────────────────────
function fetchHomepageCategories_() {
  const cache = CacheService.getScriptCache();
  const cached = cache.get('cj_homepage_categories');
  if (cached) return { ok: true, data: JSON.parse(cached) };

  const catResult = fetchCategories_();
  if (!catResult.ok) return catResult;

  const leaves = [];
  (catResult.data || []).forEach((first) => {
    (first.categoryFirstList || []).forEach((second) => {
      (second.categorySecondList || []).forEach((third) => {
        leaves.push({ id: third.categoryId, name: third.categoryName });
      });
    });
  });

  const visible = [];
  for (let i = 0; i < leaves.length; i++) {
    const leaf = leaves[i];
    const cacheKey = 'cj_products_' + leaf.id + '_1_4';
    const cachedProducts = cache.get(cacheKey);
    let products;
    if (cachedProducts) {
      products = JSON.parse(cachedProducts);
    } else {
      const data = cjGet_('/product/list', { categoryId: leaf.id, pageNum: 1, pageSize: 4 });
      if (data._httpStatus === 429 || /insufficient.*points/i.test(data.message || '')) {
        // Out of CJ points mid-scan — stop spending on the remaining leaf
        // categories (every one would fail identically) and cache what
        // succeeded so far, with a short TTL so we retry sooner once points
        // replenish instead of waiting out the full 6h TTL.
        cache.put('cj_homepage_categories', JSON.stringify(visible), 900);
        return { ok: visible.length > 0, data: visible, error: visible.length ? undefined : (data.message || 'Out of CJ API points for today') };
      }
      products = (data.result && data.data && (data.data.list || data.data.content)) || [];
      cache.put(cacheKey, JSON.stringify(products), 7200);
      Utilities.sleep(500); // only pace real CJ calls — cache hits are free
    }
    if (products.length > 0) visible.push({ categoryId: leaf.id, categoryName: leaf.name, products: products });
  }

  cache.put('cj_homepage_categories', JSON.stringify(visible), 21600); // 6h
  return { ok: true, data: visible };
}

function fetchProductDetail_(pid) {
  const data = cjGet_('/product/query', { pid: pid });
  return data.result
    ? { ok: true, data: data.data || data }
    : { ok: false, error: data.message || 'Failed to fetch product detail', data: data };
}

// Free endpoint — CJ's docs recommend this dedicated lookup over a "video"
// field on product/query (which only appears when a special enable_video
// flag is requested, and returns video IDs rather than playable URLs).
// Cached 6h since a product's video rarely changes.
function fetchProductVideos_(pid) {
  const cache = CacheService.getScriptCache();
  const cacheKey = 'cj_videos_' + pid;
  const cached = cache.get(cacheKey);
  if (cached) return { ok: true, data: JSON.parse(cached) };

  const data = cjPost_('/product/queryVideosByProductId', { productId: pid });
  // CJ returns result:false with message "success" (not an error string) when
  // the product simply has no video — treat that as an empty result, not a failure.
  if (!data.result) {
    if (/^success$/i.test(data.message || '')) return { ok: true, data: [] };
    return { ok: false, error: data.message || 'Failed to fetch product videos', data: data };
  }

  const videos = data.data || [];
  cache.put(cacheKey, JSON.stringify(videos), 21600);
  return { ok: true, data: videos };
}

// ──────────────────────────────────────────────────────────────
// PID → VID RESOLUTION (freight & orders need the variant id, not pid)
// ──────────────────────────────────────────────────────────────
function resolveVid_(pid) {
  const cache = CacheService.getScriptCache();
  const cacheKey = 'vid_' + pid;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const data = cjGet_('/product/variant/query', { pid: pid });
  let vid = null;
  if (data.result && data.data) {
    const list = Array.isArray(data.data) ? data.data : (data.data.list || [data.data]);
    if (list && list[0]) vid = list[0].vid || list[0].variantId || null;
  }
  if (!vid) vid = pid; // fall back — some responses already return a vid as pid

  cache.put(cacheKey, vid, 21600); // 6 hours
  return vid;
}

// ──────────────────────────────────────────────────────────────
// FREIGHT
// ──────────────────────────────────────────────────────────────
function calculateFreight_(payload) {
  const vid = resolveVid_(payload.productId || payload.pid || payload.vid);
  const data = cjPost_('/logistic/freightCalculate', {
    startCountryCode: 'CN',
    endCountryCode: payload.countryCode || 'US',
    products: [{ quantity: payload.quantity || 1, vid: vid }],
  });
  return data.result
    ? { ok: true, data: data.data || data }
    : { ok: false, error: data.message || 'Failed to calculate freight', data: data };
}

// ──────────────────────────────────────────────────────────────
// ORDERS
// ──────────────────────────────────────────────────────────────
function createOrder_(payload) {
  const items = (payload.products || []).map((i) => ({
    vid: resolveVid_(i.pid || i.vid),
    quantity: i.quantity || 1,
  }));

  const cjPayload = {
    orderNumber: payload.orderNumber || 'CJG-' + new Date().getTime(),
    shippingZip: payload.zipcode || payload.zip || '',
    shippingCountryCode: payload.countryCode || '',
    shippingProvince: payload.province || payload.state || '',
    shippingCity: payload.city || '',
    shippingPhone: payload.phone || '',
    shippingCustomerName: payload.name || '',
    shippingAddress: payload.address || '',
    email: payload.email || '',
    remark: payload.remark || 'CJ Globally order',
    logisticName: payload.logisticName || 'CJPacket Ordinary',
    fromCountryCode: 'CN',
    shopLogisticsType: 2,
    iossType: 1,
    products: items,
  };

  const data = cjPost_('/shopping/order/createOrderV3', cjPayload);
  return data.result
    ? { ok: true, data: data.data || data }
    : { ok: false, error: data.message || 'Failed to create order', data: data };
}

// ──────────────────────────────────────────────────────────────
// TRACKING
// ──────────────────────────────────────────────────────────────
function trackOrder_(trackingNumber) {
  const data = cjGet_('/logistic/getTrackInfo', { trackNumber: trackingNumber });
  return data.result
    ? { ok: true, data: data.data || data }
    : { ok: false, error: data.message || 'Failed to track order', data: data };
}
