/**
 * CJ GLOBALLY — Google Apps Script Proxy for CJDropshipping API
 * Paste this whole file into your Apps Script project (replacing Code.gs),
 * then Deploy > Manage deployments > Edit > New version > Deploy.
 *
 * Why this exists:
 *  - Keeps the CJ API key server-side (never shipped to the browser).
 *  - Caches the access token so pages never re-auth.
 *  - Uses /product/list (0 points/call) instead of /product/listV2
 *    (150 points/call) for all category/product browsing — this is what
 *    was burning 16,650+ points/day and triggering 429s.
 *  - Client sends POST bodies as text/plain so the browser never issues a
 *    CORS preflight (OPTIONS) request — Apps Script web apps don't answer
 *    preflights, so a JSON content-type on the client causes "Failed to
 *    fetch" even though the deployment itself is fine.
 */

// ──────────────────────────────────────────────────────────────
// CREDENTIALS (server-side only — never exposed to the browser)
// ──────────────────────────────────────────────────────────────
const CJ_API_BASE = 'https://developers.cjdropshipping.com/api2.0/v1';
const CJ_EMAIL = 'usamaestonia@gmail.com';
const CJ_API_KEY = 'CJ5580877@api@fbfc1eb42a3244a5969aa554bd5743c4'; // rotate in CJ dashboard if ever shared

// ──────────────────────────────────────────────────────────────
// AUTHENTICATION
// ──────────────────────────────────────────────────────────────
function getAccessToken_() {
  const props = PropertiesService.getScriptProperties();
  const cachedToken = props.getProperty('cj_access_token');
  const cachedTime = Number(props.getProperty('cj_access_token_time') || 0);
  const now = new Date().getTime();

  if (!cachedToken || (now - cachedTime) > (23 * 60 * 60 * 1000)) {
    const res = UrlFetchApp.fetch(CJ_API_BASE + '/authentication/getAccessToken', {
      method: 'post',
      headers: { 'Content-Type': 'application/json' },
      payload: JSON.stringify({ email: CJ_EMAIL, password: CJ_API_KEY }),
      muteHttpExceptions: true,
    });
    const json = JSON.parse(res.getContentText());
    if (json.result && json.data && json.data.accessToken) {
      props.setProperty('cj_access_token', json.data.accessToken);
      props.setProperty('cj_access_token_time', now.toString());
      return json.data.accessToken;
    }
    throw new Error('Failed to get access token: ' + JSON.stringify(json));
  }
  return cachedToken;
}

// ──────────────────────────────────────────────────────────────
// HTTP ENTRY POINTS
// ──────────────────────────────────────────────────────────────
function doGet(e) { return handleRequest_(e); }
function doPost(e) { return handleRequest_(e); }

function handleRequest_(e) {
  e = e || {};
  try {
    const params = e.parameter || {};
    let payload = {};
    if (e.postData && e.postData.contents) {
      try { payload = JSON.parse(e.postData.contents); } catch (_) { payload = {}; }
    } else {
      payload = params;
    }
    const action = payload.action || params.action || 'ping';

    let result;
    switch (action) {
      case 'categories': result = fetchCategories_(); break;
      case 'homepage_categories': result = fetchHomepageCategories_(); break;
      case 'products': result = fetchProductsByCategory_(payload.categoryId, payload.pageNum || 1, payload.pageSize || 12); break;
      case 'product_detail': result = fetchProductDetail_(payload.pid); break;
      case 'freight': result = calculateFreight_(payload); break;
      case 'create_order': result = createOrder_(payload); break;
      case 'track': result = trackOrder_(payload.trackingNumber || payload.trackNumber); break;
      case 'ping': result = { ok: true, time: new Date().toISOString() }; break;
      default: result = { ok: false, error: 'Unknown action: ' + action };
    }

    return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ──────────────────────────────────────────────────────────────
// LOW-LEVEL CJ CALLERS
// ──────────────────────────────────────────────────────────────
function cjGet_(endpoint, params) {
  const accessToken = getAccessToken_();
  const queryParams = [];
  for (const key in params) {
    if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
      queryParams.push(encodeURIComponent(key) + '=' + encodeURIComponent(params[key]));
    }
  }
  const url = CJ_API_BASE + endpoint + (queryParams.length ? '?' + queryParams.join('&') : '');
  return fetchWithRetry_(url, {
    method: 'get',
    headers: { 'CJ-Access-Token': accessToken },
    muteHttpExceptions: true,
  });
}

function cjPost_(endpoint, body) {
  const accessToken = getAccessToken_();
  return fetchWithRetry_(CJ_API_BASE + endpoint, {
    method: 'post',
    headers: { 'CJ-Access-Token': accessToken, 'Content-Type': 'application/json' },
    payload: JSON.stringify(body || {}),
    muteHttpExceptions: true,
  });
}

// A 429 means CJ rejected the request before doing anything with it, so
// retrying after a short backoff is safe (no risk of double-processing an
// order). Without this, a single rate-limit hit during the homepage's
// category scan permanently looked like "no products in this category"
// until the next full page reload retried it.
function fetchWithRetry_(url, opts) {
  const MAX_ATTEMPTS = 4;
  let json, status;
  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
    const res = UrlFetchApp.fetch(url, opts);
    status = res.getResponseCode();
    try { json = JSON.parse(res.getContentText()); } catch (_) { json = { raw: res.getContentText() }; }
    json._httpStatus = status;
    if (status !== 429 && json.code !== 429) break;
    if (attempt < MAX_ATTEMPTS - 1) Utilities.sleep(1000 * Math.pow(2, attempt)); // 1s, 2s, 4s
  }
  return json;
}

// ──────────────────────────────────────────────────────────────
// CATEGORIES (cached 6h — this list barely changes)
// ──────────────────────────────────────────────────────────────
function fetchCategories_() {
  const cache = CacheService.getScriptCache();
  const cached = cache.get('cj_categories');
  if (cached) return { ok: true, data: JSON.parse(cached) };

  const data = cjGet_('/product/getCategory', {});
  if (!data.result) return { ok: false, error: data.message || 'Failed to fetch categories', data: data };

  cache.put('cj_categories', JSON.stringify(data.data || []), 21600); // 6 hours
  return { ok: true, data: data.data || [] };
}

// ──────────────────────────────────────────────────────────────
// PRODUCTS — /product/list is 0 points/call vs listV2's 150/call.
// Cached 30 min per (categoryId, page) so repeat visits cost nothing.
// ──────────────────────────────────────────────────────────────
function fetchProductsByCategory_(categoryId, pageNum, pageSize) {
  const cache = CacheService.getScriptCache();
  const cacheKey = 'cj_products_' + categoryId + '_' + pageNum + '_' + pageSize;
  const cached = cache.get(cacheKey);
  if (cached) return { ok: true, data: JSON.parse(cached) };

  const data = cjGet_('/product/list', { categoryId: categoryId, pageNum: pageNum, pageSize: pageSize });
  if (!data.result) return { ok: false, error: data.message || 'Failed to fetch products', data: data };

  const list = (data.data && (data.data.list || data.data.content)) || [];
  cache.put(cacheKey, JSON.stringify(list), 1800); // 30 min
  return { ok: true, data: list };
}

// ──────────────────────────────────────────────────────────────
// HOMEPAGE — one cached call that scans every leaf category for in-stock
// products, instead of the browser firing one request per category. That
// per-visitor fan-out (dozens of calls a few hundred ms apart) is what was
// tripping CJ's rate limit and leaving categories permanently blank.
// Cached 1h, so the full scan runs at most once/hour regardless of traffic.
// ──────────────────────────────────────────────────────────────
function fetchHomepageCategories_() {
  const cache = CacheService.getScriptCache();
  const cached = cache.get('cj_homepage_categories');
  if (cached) return { ok: true, data: JSON.parse(cached) };

  const catResult = fetchCategories_();
  if (!catResult.ok) return catResult;

  const leaves = [];
  (catResult.data || []).forEach((first) => {
    (first.categoryFirstList || []).forEach((second) => {
      (second.categorySecondList || []).forEach((third) => {
        leaves.push({ id: third.categoryId, name: third.categoryName });
      });
    });
  });

  const visible = [];
  leaves.forEach((leaf) => {
    const cacheKey = 'cj_products_' + leaf.id + '_1_4';
    const cachedProducts = cache.get(cacheKey);
    let products;
    if (cachedProducts) {
      products = JSON.parse(cachedProducts);
    } else {
      const data = cjGet_('/product/list', { categoryId: leaf.id, pageNum: 1, pageSize: 4 });
      products = (data.result && data.data && (data.data.list || data.data.content)) || [];
      cache.put(cacheKey, JSON.stringify(products), 1800);
      Utilities.sleep(500); // only pace real CJ calls — cache hits are free
    }
    if (products.length > 0) visible.push({ categoryId: leaf.id, categoryName: leaf.name, products: products });
  });

  cache.put('cj_homepage_categories', JSON.stringify(visible), 3600); // 1 hour
  return { ok: true, data: visible };
}

function fetchProductDetail_(pid) {
  const data = cjGet_('/product/query', { pid: pid });
  return data.result
    ? { ok: true, data: data.data || data }
    : { ok: false, error: data.message || 'Failed to fetch product detail', data: data };
}

// ──────────────────────────────────────────────────────────────
// PID → VID RESOLUTION (freight & orders need the variant id, not pid)
// ──────────────────────────────────────────────────────────────
function resolveVid_(pid) {
  const cache = CacheService.getScriptCache();
  const cacheKey = 'vid_' + pid;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const data = cjGet_('/product/variant/query', { pid: pid });
  let vid = null;
  if (data.result && data.data) {
    const list = Array.isArray(data.data) ? data.data : (data.data.list || [data.data]);
    if (list && list[0]) vid = list[0].vid || list[0].variantId || null;
  }
  if (!vid) vid = pid; // fall back — some responses already return a vid as pid

  cache.put(cacheKey, vid, 21600); // 6 hours
  return vid;
}

// ──────────────────────────────────────────────────────────────
// FREIGHT
// ──────────────────────────────────────────────────────────────
function calculateFreight_(payload) {
  const vid = resolveVid_(payload.productId || payload.pid || payload.vid);
  const data = cjPost_('/logistic/freightCalculate', {
    startCountryCode: 'CN',
    endCountryCode: payload.countryCode || 'US',
    products: [{ quantity: payload.quantity || 1, vid: vid }],
  });
  return data.result
    ? { ok: true, data: data.data || data }
    : { ok: false, error: data.message || 'Failed to calculate freight', data: data };
}

// ──────────────────────────────────────────────────────────────
// ORDERS
// ──────────────────────────────────────────────────────────────
function createOrder_(payload) {
  const items = (payload.products || []).map((i) => ({
    vid: resolveVid_(i.pid || i.vid),
    quantity: i.quantity || 1,
  }));

  const cjPayload = {
    orderNumber: payload.orderNumber || 'CJG-' + new Date().getTime(),
    shippingZip: payload.zipcode || payload.zip || '',
    shippingCountryCode: payload.countryCode || '',
    shippingProvince: payload.province || payload.state || '',
    shippingCity: payload.city || '',
    shippingPhone: payload.phone || '',
    shippingCustomerName: payload.name || '',
    shippingAddress: payload.address || '',
    email: payload.email || '',
    remark: payload.remark || 'CJ Globally order',
    logisticName: payload.logisticName || 'CJPacket Ordinary',
    fromCountryCode: 'CN',
    shopLogisticsType: 2,
    iossType: 1,
    products: items,
  };

  const data = cjPost_('/shopping/order/createOrderV3', cjPayload);
  return data.result
    ? { ok: true, data: data.data || data }
    : { ok: false, error: data.message || 'Failed to create order', data: data };
}

// ──────────────────────────────────────────────────────────────
// TRACKING
// ──────────────────────────────────────────────────────────────
function trackOrder_(trackingNumber) {
  const data = cjGet_('/logistic/getTrackInfo', { trackNumber: trackingNumber });
  return data.result
    ? { ok: true, data: data.data || data }
    : { ok: false, error: data.message || 'Failed to track order', data: data };
}
