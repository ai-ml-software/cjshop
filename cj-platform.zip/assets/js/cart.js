/* =========================================================
   CJ Globally — Cart (localStorage-backed)
   Real multi-item cart so "Add to Order" means something distinct
   from "Buy Now" — items collected here are sent as the `products`
   array to shopping/order/createOrderV3 (which already accepts one
   order with multiple pid/vid + quantity lines).
   ========================================================= */
const Cart = (() => {
  const KEY = "cj_cart_v1";

  function read() {
    try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (_) { return []; }
  }
  function write(items) {
    localStorage.setItem(KEY, JSON.stringify(items));
    document.dispatchEvent(new CustomEvent("cj-cart-updated", { detail: { items } }));
    return items;
  }
  function add(item) {
    const items = read();
    const existing = items.find((i) => i.pid === item.pid);
    if (existing) existing.quantity += item.quantity || 1;
    else items.push({ pid: item.pid, title: item.title, price: item.price, image: item.image, quantity: item.quantity || 1 });
    return write(items);
  }
  function remove(pid) {
    return write(read().filter((i) => i.pid !== pid));
  }
  function updateQuantity(pid, quantity) {
    const items = read();
    const item = items.find((i) => i.pid === pid);
    if (item) item.quantity = Math.max(1, Number(quantity) || 1);
    return write(items);
  }
  function clear() { return write([]); }
  function count() { return read().reduce((n, i) => n + i.quantity, 0); }

  return { get: read, add, remove, updateQuantity, clear, count };
})();
