/* =========================================================
   CJ Globally — Shared header / footer injector
   Keeps the enterprise nav and full sitemap footer identical
   across every page without duplicating markup per file.
   ========================================================= */
(function () {
  const ROOT = window.CJ_ROOT || "."; // pages in subfolders set window.CJ_ROOT = ".." before loading this script

  const headerHtml = `
    <header class="site">
      <div class="nav-wrap">
        <a class="logo" href="${ROOT}/index.html" aria-label="CJ Globally home">CJ<span>Globally</span></a>
        <nav class="nav-links" aria-label="Primary">
          <a href="${ROOT}/index.html#categories">Catalog</a>
          <a href="${ROOT}/orders/index.html">Orders</a>
          <a href="${ROOT}/disputes/index.html">Disputes</a>
          <a href="${ROOT}/admin/settings.html">Admin</a>
        </nav>
        <a class="nav-cta" href="${ROOT}/orders/create.html">Create Order</a>
      </div>
    </header>`;

  const footerHtml = `
    <footer class="site-footer">
      <div class="footer-inner">
        <div>
          <div class="footer-brand">CJ<span style="color:#5b8bff">Globally</span></div>
          <p style="max-width:260px;font-size:13px;line-height:1.6;">Enterprise dropshipping infrastructure powered by the CJDropshipping API — sourcing, fulfillment, and logistics in one platform.</p>
        </div>
        <div class="footer-cols">
          <div class="footer-col">
            <h4>Storefront</h4>
            <a href="${ROOT}/index.html">Catalog Home</a>
            <a href="${ROOT}/index.html#categories">Categories</a>
          </div>
          <div class="footer-col">
            <h4>Orders</h4>
            <a href="${ROOT}/orders/index.html">Order List</a>
            <a href="${ROOT}/orders/create.html">Create Order</a>
            <a href="${ROOT}/orders/track.html">Track Shipment</a>
          </div>
          <div class="footer-col">
            <h4>Support</h4>
            <a href="${ROOT}/disputes/index.html">Disputes</a>
            <a href="${ROOT}/admin/webhooks.html">Webhooks</a>
          </div>
          <div class="footer-col">
            <h4>Admin</h4>
            <a href="${ROOT}/admin/inventory.html">Inventory</a>
            <a href="${ROOT}/admin/vendors.html">Vendors &amp; Shops</a>
            <a href="${ROOT}/admin/settings.html">Account Settings</a>
          </div>
        </div>
      </div>
      <div class="footer-bottom">&copy; 2026 CJ Globally. All rights reserved. Powered by the CJDropshipping API.</div>
    </footer>`;

  document.addEventListener("DOMContentLoaded", () => {
    const headerMount = document.getElementById("site-header");
    const footerMount = document.getElementById("site-footer");
    if (headerMount) headerMount.outerHTML = headerHtml;
    if (footerMount) footerMount.outerHTML = footerHtml;
  });
})();
