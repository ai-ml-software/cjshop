/* =========================================================
   CJ Globally — Shared header / footer injector
   Keeps the enterprise nav and full sitemap footer identical
   across every page without duplicating markup per file.
   ========================================================= */
(function () {
  const ROOT = window.CJ_ROOT || "."; // pages in subfolders set window.CJ_ROOT = ".." before loading this script

  const headerHtml = `
    <header class="site">
      <div class="nav-wrap">
        <a class="logo" href="${ROOT}/index.html" aria-label="CJ Globally home">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6"/><path d="M3 12h18M12 3c2.8 2.6 4.2 5.8 4.2 9s-1.4 6.4-4.2 9c-2.8-2.6-4.2-5.8-4.2-9s1.4-6.4 4.2-9Z" stroke="currentColor" stroke-width="1.6"/></svg>
          CJ<span>Globally</span>
        </a>
        <nav class="nav-links" aria-label="Primary">
          <a href="${ROOT}/index.html#categories">Catalog</a>
          <a href="${ROOT}/categories.html">All Categories</a>
          <a href="${ROOT}/orders/index.html">Orders</a>
          <a href="${ROOT}/disputes/index.html">Disputes</a>
          <a href="${ROOT}/admin/settings.html">Admin</a>
        </nav>
        <a class="cart-link" href="${ROOT}/orders/create.html?fromCart=1" aria-label="View cart">
          <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M3 4h2l1 3m0 0 1.6 8.2A2 2 0 0 0 9.5 17h7.8a2 2 0 0 0 2-1.6L21 8H6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="10" cy="21" r="1.4" fill="currentColor"/><circle cx="18" cy="21" r="1.4" fill="currentColor"/></svg>
          <span class="cart-count" id="cart-count">0</span>
        </a>
        <a class="nav-cta" href="${ROOT}/orders/create.html">Create Order</a>
      </div>
    </header>`;

  const footerHtml = `
    <footer class="site-footer">
      <div class="footer-inner">
        <div>
          <div class="footer-brand">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6"/><path d="M3 12h18M12 3c2.8 2.6 4.2 5.8 4.2 9s-1.4 6.4-4.2 9c-2.8-2.6-4.2-5.8-4.2-9s1.4-6.4 4.2-9Z" stroke="currentColor" stroke-width="1.6"/></svg>
            CJ<span>Globally</span>
          </div>
          <p style="max-width:260px;font-size:13px;line-height:1.6;">Enterprise dropshipping infrastructure powered by the CJDropshipping API — sourcing, fulfillment, and logistics in one platform.</p>
        </div>
        <div class="footer-cols">
          <div class="footer-col">
            <h4>Storefront</h4>
            <a href="${ROOT}/index.html">Catalog Home</a>
            <a href="${ROOT}/categories.html">All Categories</a>
          </div>
          <div class="footer-col">
            <h4>Orders</h4>
            <a href="${ROOT}/orders/index.html">Order List</a>
            <a href="${ROOT}/orders/create.html">Create Order</a>
            <a href="${ROOT}/orders/track.html">Track Shipment</a>
          </div>
          <div class="footer-col">
            <h4>Support</h4>
            <a href="${ROOT}/disputes/index.html">Disputes</a>
            <a href="${ROOT}/admin/webhooks.html">Webhooks</a>
          </div>
          <div class="footer-col">
            <h4>Admin</h4>
            <a href="${ROOT}/admin/inventory.html">Inventory</a>
            <a href="${ROOT}/admin/vendors.html">Vendors &amp; Shops</a>
            <a href="${ROOT}/admin/settings.html">Account Settings</a>
          </div>
        </div>
      </div>
      <div class="footer-bottom">&copy; 2026 CJ Globally. All rights reserved. Powered by the CJDropshipping API.</div>
    </footer>`;

  function refreshCartBadge() {
    const el = document.getElementById("cart-count");
    if (el && window.Cart) el.textContent = String(Cart.count());
  }

  window.showToast = function showToast(message) {
    let el = document.getElementById("cj-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "cj-toast";
      el.className = "toast";
      document.body.appendChild(el);
    }
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(el._hideTimer);
    el._hideTimer = setTimeout(() => el.classList.remove("show"), 2200);
  };

  document.addEventListener("DOMContentLoaded", () => {
    const headerMount = document.getElementById("site-header");
    const footerMount = document.getElementById("site-footer");
    if (headerMount) headerMount.outerHTML = headerHtml;
    if (footerMount) footerMount.outerHTML = footerHtml;
    refreshCartBadge();
  });
  document.addEventListener("cj-cart-updated", refreshCartBadge);
})();
