/* =========================================================
   CJ Globally — API Client
   Storefront-critical calls (categories, products, product detail,
   freight, order create/track) go through the Google Apps Script
   proxy in cj-platform/gas-proxy/Code.gs — this keeps the CJ API
   key server-side and avoids the browser being rate-limited (429)
   for calling CJ directly.

   Set GAS_PROXY_URL below to your deployed /exec URL.
   ========================================================= */
const CJ = (() => {
  const GAS_PROXY_URL = "https://script.google.com/macros/s/AKfycbwTu_x3ZWgTvYC4gKZBaEKk3tC4hHzmlqOJNxFSq0faSmfW2J1VyMVv8iJtZNEZ_cXB/exec";

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // text/plain avoids a CORS preflight (OPTIONS) — Apps Script web apps
  // don't answer preflight requests, so application/json here breaks silently.
  async function proxyCall(action, payload, retries = 3) {
    console.debug(`[CJ debug] → ${action}`, payload);
    const res = await fetch(GAS_PROXY_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({ action, ...payload }),
    });
    if (!res.ok) {
      if (retries > 0) { await sleep(800); return proxyCall(action, payload, retries - 1); }
      throw new Error(`Proxy request failed: ${action} (${res.status})`);
    }
    const json = await res.json();
    console.debug(`[CJ debug] ← ${action}`, json);
    if (!json.ok) throw new Error(json.error || `Proxy action "${action}" failed`);
    return json.data;
  }

  // ---------- Direct-to-CJ fallback (admin pages only — not rate-limit-safe) ----------
  const BASE_URL = "https://developers.cjdropshipping.com/api2.0/v1";
  const EMAIL = "usamaestonia@gmail.com";
  const API_KEY = "CJ5580877@api@fbfc1eb42a3244a5969aa554bd5743c4";
  const TOKEN_STORAGE_KEY = "cj_direct_token_v1";
  let tokenRequest = null;

  // accessToken/tokenExpiry are plain JS vars that reset on every page
  // navigation, so browsing category -> product -> product re-authenticated
  // against CJ from scratch each time — a steady drip of auth requests that
  // was tripping CJ's rate limit on getAccessToken. sessionStorage survives
  // navigation within the same tab, so the token is fetched at most once per
  // browsing session instead of once per page.
  function readStoredToken_() {
    try {
      const raw = sessionStorage.getItem(TOKEN_STORAGE_KEY);
      if (!raw) return null;
      const { token, expiry } = JSON.parse(raw);
      return token && Date.now() < expiry ? { token, expiry } : null;
    } catch (_) { return null; }
  }
  function writeStoredToken_(token, expiry) {
    try { sessionStorage.setItem(TOKEN_STORAGE_KEY, JSON.stringify({ token, expiry })); } catch (_) { /* storage unavailable/full — token still works in-memory for this page */ }
  }

  let accessToken = null, tokenExpiry = 0;
  const getCache = new Map();
  const CACHE_TTL_MS = 1000 * 60 * 30;

  // Callers that fire concurrently on a fresh page load (e.g. product.html's
  // Promise.all of queryVariants + productComments) would otherwise each see
  // no cached token and POST to the auth endpoint at the same instant — a
  // duplicate burst that's a likely cause of 429s on getAccessToken itself.
  // Sharing one in-flight request means concurrent callers await the same call.
  async function getAccessTokenDirect_() {
    if (accessToken && Date.now() < tokenExpiry) return accessToken;
    const stored = readStoredToken_();
    if (stored) { accessToken = stored.token; tokenExpiry = stored.expiry; return accessToken; }
    if (tokenRequest) return tokenRequest;
    tokenRequest = (async () => {
      try {
        const res = await fetch(`${BASE_URL}/authentication/getAccessToken`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: EMAIL, password: API_KEY }),
        });
        if (!res.ok) throw new Error("Auth failed: " + res.status);
        const data = await res.json();
        if (!data?.result) throw new Error(data?.message || "Auth rejected");
        accessToken = data.data.accessToken;
        tokenExpiry = Date.now() + 1000 * 60 * 60 * 24 * 14;
        writeStoredToken_(accessToken, tokenExpiry);
        return accessToken;
      } finally {
        tokenRequest = null;
      }
    })();
    return tokenRequest;
  }

  async function authedFetch(path, options = {}, retries = 4, useCache = true) {
    const method = options.method || "GET";
    if (method === "GET" && useCache) {
      const cached = getCache.get(path);
      if (cached && Date.now() - cached.ts < CACHE_TTL_MS) return cached.data;
    }
    const token = await getAccessTokenDirect_();
    const res = await fetch(`${BASE_URL}${path}`, {
      ...options,
      headers: { "Content-Type": "application/json", "CJ-Access-Token": token, ...(options.headers || {}) },
    });
    if (res.status === 429 && retries > 0) {
      const retryAfter = Number(res.headers.get("Retry-After")) || 0;
      await sleep(retryAfter * 1000 || (5 - retries) * 1200);
      return authedFetch(path, options, retries - 1, useCache);
    }
    if (!res.ok) throw new Error(`Request failed: ${path} (${res.status})`);
    const data = await res.json();
    if (method === "GET" && useCache) getCache.set(path, { data, ts: Date.now() });
    return data;
  }

  const qs = (params) => Object.entries(params || {})
    .filter(([, v]) => v !== undefined && v !== null && v !== "")
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
  const get = (path, params) => authedFetch(`${path}${params ? "?" + qs(params) : ""}`, { method: "GET" });
  const post = (path, body) => authedFetch(path, { method: "POST", body: JSON.stringify(body || {}) }, 4, false);

  // CJ's API points are a single shared account-wide budget — if the proxy
  // failed because the account is out of points today, retrying direct-to-CJ
  // is guaranteed to fail identically (same account, same exhausted budget)
  // and only wastes more of the ~1 pt/sec trickle-replenishment. Skip it.
  const isQuotaExhausted_ = (err) => /insufficient.*points?/i.test(err?.message || "");

  // ---------- Dual-path: try the GAS proxy first, fall back to calling CJ
  // directly from the browser if the proxy errors (deployment down/misconfigured,
  // wrong URL after a redeploy, CORS/network failure, etc). The direct path
  // skips the proxy's server-side cache, so it's a fallback, not the default —
  // but it means one broken path doesn't take products down.
  async function withFallback_(label, proxyFn, directFn) {
    try {
      const data = await proxyFn();
      console.debug(`[CJ debug] ${label}: proxy OK`, data);
      return { result: true, data, source: "proxy" };
    } catch (proxyErr) {
      if (isQuotaExhausted_(proxyErr)) {
        console.error(`[CJ debug] ${label}: CJ account is out of API points for today — skipping direct fallback (same shared quota, would fail identically)`, proxyErr);
        return { result: false, message: proxyErr.message, source: "none" };
      }
      console.warn(`[CJ debug] ${label}: proxy failed (${proxyErr.message}) — trying direct-to-CJ`, proxyErr);
      try {
        const data = await directFn();
        console.debug(`[CJ debug] ${label}: direct OK`, data);
        return { result: true, data, source: "direct" };
      } catch (directErr) {
        console.error(`[CJ debug] ${label}: both proxy and direct failed`, { proxyErr, directErr });
        return { result: false, message: `proxy: ${proxyErr.message} | direct: ${directErr.message}`, source: "none" };
      }
    }
  }

  const getCategoryDirect_ = () => get("/product/getCategory");
  const listProductsDirect_ = (categoryId, pageNum, pageSize) => get("/product/list", { categoryId, pageNum, pageSize });
  const queryProductDirect_ = (pid) => get("/product/query", { pid });
  const queryProductVideosDirect_ = (pid) => post("/product/queryVideosByProductId", { productId: pid });

  // Client-side re-implementation of the proxy's homepage scan, used only
  // when the proxy itself is unreachable. Capped and paced conservatively
  // since it skips the proxy's server-side cache and is more likely to hit
  // CJ's rate limit.
  async function getHomepageCategoriesDirect_() {
    const catRes = await getCategoryDirect_();
    if (!catRes?.result) throw new Error(catRes?.message || "Direct category fetch failed");
    const tree = catRes.data || [];
    const leaves = [];
    tree.forEach((first) => {
      (first.categoryFirstList || []).forEach((second) => {
        (second.categorySecondList || []).forEach((third) => {
          leaves.push({ id: third.categoryId, name: third.categoryName });
        });
      });
    });
    const MAX_CATEGORIES = 24;
    const targets = leaves.slice(0, MAX_CATEGORIES);
    console.warn(`[CJ debug] getHomepageCategories direct fallback: scanning ${targets.length}/${leaves.length} categories client-side (unproxied, uncached)`);
    const visible = [];
    for (const leaf of targets) {
      try {
        const res = await listProductsDirect_(leaf.id, 1, 4);
        const list = (res?.data && (res.data.list || res.data.content)) || [];
        if (list.length > 0) visible.push({ categoryId: leaf.id, categoryName: leaf.name, products: list });
      } catch (err) {
        if (isQuotaExhausted_(err)) {
          console.error(`[CJ debug] direct fallback: out of CJ API points — stopping scan early (${visible.length}/${targets.length} categories checked)`, err);
          break;
        }
        console.warn(`[CJ debug] direct category check failed for ${leaf.id}: ${err.message}`);
      }
      await sleep(600);
    }
    return visible;
  }

  return {
    sleep,

    // ---------- Proxy-backed, with direct-to-CJ fallback if the proxy fails ----------
    getCategory: () => withFallback_(
      "getCategory",
      () => proxyCall("categories", {}),
      () => getCategoryDirect_().then((res) => {
        if (!res?.result) throw new Error(res?.message || "Direct category fetch failed");
        return res.data;
      })
    ),
    getHomepageCategories: () => withFallback_(
      "getHomepageCategories",
      () => proxyCall("homepage_categories", {}),
      () => getHomepageCategoriesDirect_()
    ),
    listProducts: ({ categoryId, pageNum, pageSize }) => withFallback_(
      "listProducts",
      () => proxyCall("products", { categoryId, pageNum, pageSize }).then((list) => ({ list })),
      () => listProductsDirect_(categoryId, pageNum, pageSize).then((res) => {
        if (!res?.result) throw new Error(res?.message || "Direct product list failed");
        return { list: (res.data && (res.data.list || res.data.content)) || [] };
      })
    ),
    queryProducts: ({ pid }) => withFallback_(
      "queryProducts",
      () => proxyCall("product_detail", { pid }),
      () => queryProductDirect_(pid).then((res) => {
        if (!res?.result) throw new Error(res?.message || "Direct product query failed");
        return res.data;
      })
    ),
    getProductVideos: (pid) => withFallback_(
      "getProductVideos",
      () => proxyCall("product_videos", { pid }),
      () => queryProductVideosDirect_(pid).then((res) => {
        if (!res?.result) {
          if (/^success$/i.test(res?.message || "")) return [];
          throw new Error(res?.message || "Direct product video query failed");
        }
        return res.data || [];
      })
    ),
    freightCalculate: (payload) => proxyCall("freight", payload).then((data) => ({ result: true, data })),
    createOrderV3: (payload) => proxyCall("create_order", payload).then((data) => ({ result: true, data })),
    getTrackInfo: (trackingNumber) => proxyCall("track", { trackingNumber }).then((data) => ({ result: true, data })),

    // ---------- Direct-to-CJ (admin/back-office pages — lower traffic, not proxied yet) ----------
    getPlatformCategoryTree: () => get("/product/listed/getPlatformCategoryTree"),
    listV2: (params) => get("/product/listV2", params), // 50 pts/call — same cost as /product/list, kept only for reference
    queryProductsByImage: (imageUrl) => post("/product/queryProductsByImage", { imageUrl }),
    listedByPids: (pids) => post("/product/listed/listedByPids", { pids }),
    queryVendors: (params) => get("/product/listed/queryVendors", params),
    queryDeliveryProfiles: (params) => get("/product/listed/queryDeliveryProfiles", params),
    getReceiverCountryInfo: () => get("/product/listed/getReceiverCountryInfo"),
    queryVariants: (pid) => get("/product/variant/query", { pid }),
    queryVariantByVid: (vid) => get("/product/variant/queryByVid", { vid }),
    productComments: (params) => get("/product/productComments", params),
    comments: (params) => get("/product/comments", params),
    sourcingQuery: (params) => get("/product/sourcing/query", params),
    sourcingCreate: (payload) => post("/product/sourcing/create", payload),
    stockQueryBySku: (sku) => get("/product/stock/queryBySku", { sku }),
    stockQueryByVid: (vid) => get("/product/stock/queryByVid", { vid }),
    getInventoryByPid: (pid) => get("/product/stock/getInventoryByPid", { pid }),
    privateInventorySkuDetailPage: (params) => get("/product/stock/privateInventory/querySkuDetailPage", params),
    privateInventorySkuFlow: (params) => get("/product/stock/privateInventory/querySkuFlowByCondition", params),
    privateInventorySkuDetailListBySku: (sku) => get("/product/stock/privateInventory/querySkuDetailListBySku", { sku }),
    privateInventorySkuListByProductId: (productId) => get("/product/stock/privateInventory/querySkuListByProductId", { productId }),
    privateInventorySpuPage: (params) => get("/product/stock/privateInventory/querySpuPage", params),
    freightCalculateTip: (payload) => post("/logistic/freightCalculateTip", payload),
    partnerFreightCalculate: (payload) => post("/logistic/partnerFreightCalculate", payload),
    trackInfo: (params) => get("/logistic/trackInfo", params),
    getSupplierLogisticsTemplate: (params) => get("/logistic/getSupplierLogisticsTemplate", params),
    orderList: (params) => get("/shopping/order/list", params),
    getOrderDetail: (orderId) => get("/shopping/order/getOrderDetail", { orderId }),
    createOrderV2: (payload) => post("/shopping/order/createOrderV2", payload),
    confirmOrder: (orderId) => post("/shopping/order/confirmOrder", { orderId }),
    deleteOrder: (orderId) => post("/shopping/order/deleteOrder", { orderId }),
    getBalance: () => get("/shopping/pay/getBalance"),
    payBalance: (payload) => post("/shopping/pay/payBalance", payload),
    getDisputeList: (params) => get("/disputes/getDisputeList", params),
    disputeProducts: (orderId) => get("/disputes/disputeProducts", { orderId }),
    disputeConfirmInfo: (disputeId) => get("/disputes/disputeConfirmInfo", { disputeId }),
    createDispute: (payload) => post("/disputes/create", payload),
    cancelDispute: (disputeId) => post("/disputes/cancel", { disputeId }),
    webhookSettingList: () => get("/webhook/setting/list"),
    webhookProductSubscribe: (payload) => post("/webhook/product/subscribe", payload),
    webhookProductSubscribeList: () => get("/webhook/product/subscribe/list"),
    webhookProductUnsubscribe: (payload) => post("/webhook/product/unsubscribe", payload),
    getShops: () => get("/shop/getShops"),
    getSetting: () => get("/setting/get"),
    platformApiCall: (payload) => post("/platform/api/call", payload),
    syncStorehouseVideoRequests: (payload) => post("/storehouseCenterWeb/syncStorehouseVideoRequests", payload),
  };
})();
