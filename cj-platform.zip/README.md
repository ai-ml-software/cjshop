# CJ Globally — Storefront Platform

A static HTML/JS storefront + back-office console for CJDropshipping, built to avoid
the two failure modes of a plain client-side integration: burning API points on
`listV2` (150 pts/call) and getting rate-limited (HTTP 429) by fanning out too many
requests directly from the browser.

## How it works

```
Browser (index.html, category.html, product.html, orders/*, disputes/*, admin/*)
   │  fetch(GAS_PROXY_URL, { action, ...payload })   — POST, text/plain body
   ▼
Google Apps Script Web App (gas-proxy/Code.gs)
   │  UrlFetchApp.fetch(...)  — CJ-Access-Token header, retries on 429
   ▼
CJ Dropshipping API (developers.cjdropshipping.com/api2.0/v1)
```

- **The CJ API key lives only in `Code.gs`**, server-side. The browser never sees it
  for any storefront-critical call (categories, products, product detail, freight,
  order create/track).
- **POST bodies are sent as `text/plain`**, not `application/json` — Apps Script web
  apps don't answer CORS preflight (OPTIONS) requests, so a JSON content-type causes a
  silent "Failed to fetch" even when the deployment itself is fine.
- **`/product/list` (0 pts/call) is used instead of `/product/listV2` (150 pts/call)**
  everywhere the storefront just needs to browse or check stock.
- **429s are retried server-side** with exponential backoff (1s/2s/4s) in
  `fetchWithRetry_` — a 429 means CJ rejected the request before processing it, so
  retrying is safe (no risk of a duplicate order).
- **The homepage's full category scan runs once, server-side, and is cached for an
  hour** (`fetchHomepageCategories_`, action `homepage_categories`). Earlier versions
  had the browser fire one live request per leaf category on every page load, which
  is what was tripping CJ's rate limit and leaving categories blank.
- **Categories, products, and product detail try the proxy first, then fall back to
  calling CJ directly from the browser** if the proxy call throws (`withFallback_` in
  `cj-api.js`) — a broken/stale/misconfigured Apps Script deployment no longer takes
  the whole storefront down. The direct fallback re-authenticates with CJ itself, skips
  the proxy's server-side cache, and paces its own homepage category scan more slowly
  (24-category cap, 600ms between calls) since it's not rate-limit-protected the way
  the proxy path is. Every call logs which path served it — see **Debugging** below.

## Current deployment

| | |
|---|---|
| Web app URL | `https://script.google.com/macros/s/AKfycbzJ_FElaZLMqBAhs5gpzP_xGYLyu2fe5iZomP6YGMgCSt7GmOlgFTSJ5X-XJOFc20IL/exec` |
| Deployment version | 1 (8 Jul 2026, 14:19) |
| Configured in | `assets/js/cj-api.js` → `GAS_PROXY_URL` |

**If you redeploy `Code.gs` as a new version, the `/exec` URL usually changes** —
update `GAS_PROXY_URL` in `assets/js/cj-api.js` to match, otherwise the storefront
keeps talking to the old (stale) deployment.

## Deploying a change to `Code.gs`

1. Open your Apps Script project → paste the full contents of `gas-proxy/Code.gs`
   over the existing `Code.gs`, replacing it entirely.
2. **Deploy → Manage deployments → Edit (pencil icon) → Version: New version → Deploy.**
3. Copy the resulting Web app URL into `assets/js/cj-api.js`'s `GAS_PROXY_URL` if it
   changed.
4. Hard-refresh the storefront (cached JSON responses from `CacheService` persist
   server-side for up to an hour regardless of client-side cache/reload).

## File map

| Path | Purpose |
|---|---|
| `index.html` | Homepage — category sections populated from one cached `homepage_categories` call |
| `category.html` | 12/page product grid + "Load More" (`product/list`) |
| `product.html` | Product detail: `product/query`, `product/variant/query`, `product/productComments`, freight |
| `orders/index.html` | Order list + live balance (`shopping/order/list`, `shopping/pay/getBalance`) |
| `orders/detail.html` | Confirm / delete / dispute-link (`getOrderDetail`, `confirmOrder`, `deleteOrder`) |
| `orders/create.html` | New order form + freight calculator |
| `orders/track.html` | Shipment tracking (`logistic/getTrackInfo`) |
| `disputes/index.html` | Dispute list + cancel |
| `disputes/create.html` | File a dispute against an order |
| `admin/webhooks.html` | Webhook settings + product subscribe/unsubscribe |
| `admin/inventory.html` | Stock lookup by SKU/VID/PID + private-warehouse SPU overview |
| `admin/vendors.html` | Connected shops, vendors, delivery profiles |
| `admin/settings.html` | Balance, account settings, country coverage |
| `assets/js/cj-api.js` | Every CJ endpoint wrapped; proxy-backed calls are rate-limit-safe, the rest are direct-to-CJ (admin pages only) |
| `assets/js/layout.js` | Shared header + sitemap footer, injected on every page |
| `assets/css/theme.css` | Shared design system |
| `gas-proxy/Code.gs` | The Apps Script source — copy/paste into your Apps Script project (not auto-deployed from this repo) |

## Caching (Apps Script `CacheService`)

| Cache key | TTL | What it holds |
|---|---|---|
| `cj_categories` | 6h | Full category tree |
| `cj_homepage_categories` | 1h | Aggregated "categories with in-stock products" for the homepage |
| `cj_products_<categoryId>_<page>_<size>` | 30min | Product list per category/page |
| `vid_<pid>` | 6h | Resolved variant ID for a product ID |
| `cj_access_token` (PropertiesService) | 23h | CJ access token |

## Debugging

Every category/product call logs to the console (`console.debug`/`console.warn`/
`console.error`, prefixed `[CJ debug]`) — open DevTools with the Console level set to
"Verbose" (Chrome hides `console.debug` under the default "Info" filter) to see it:

- `[CJ debug] → <action>` / `← <action>` — every proxy request/response, from `proxyCall`.
- `[CJ debug] <label>: proxy OK` / `proxy failed (...) — trying direct-to-CJ` /
  `direct OK` / `both proxy and direct failed` — from `withFallback_`, shows exactly
  which path (proxy vs. direct) served each `getCategory` / `getHomepageCategories` /
  `listProducts` / `queryProducts` call, and why it fell back if it did.
- Page-level logs in `index.html`, `category.html`, and `product.html` print the raw
  response and the extracted list/product alongside the `source` (`"proxy"` or
  `"direct"`) that produced it.

If products still don't show after checking the console: an empty `data` array with
`source: "proxy"` means CJ itself returned no products for that category (or the
proxy's cache is stale — wait out the TTL or clear `CacheService` by redeploying);
`source: "direct"` means the proxy failed first (check the `proxy failed (...)` log
line for why — wrong `GAS_PROXY_URL`, expired Apps Script deployment, etc.); and
`both proxy and direct failed` means CJ itself is rejecting both paths (rate limit,
expired credentials, or an account-level issue — check the CJ dashboard).

## Known limitations

- **Admin/back-office pages call CJ directly from the browser** (`assets/js/cj-api.js`,
  "Direct-to-CJ fallback" section) — the CJ API key is visible in that file's source.
  These are lower-traffic, internal-use pages, but if this platform is ever exposed
  publicly, route them through the proxy too before that happens.
- CJ's rate limit is tied to the API key/account as a whole, not per-caller — testing
  directly against `developers.cjdropshipping.com` (e.g. via CJ's own API console)
  shares the same budget as this app's traffic and can trigger 429s independently of
  anything in this repo.
