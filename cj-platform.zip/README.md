# CJ Globally — Storefront Platform

A static HTML/JS storefront + back-office console for CJDropshipping, built to avoid
the two failure modes of a plain client-side integration: burning through CJ's daily
API point budget, and getting rate-limited (HTTP 429) by fanning out too many
requests directly from the browser.

## API points — read this before changing cache TTLs

Per CJ's own docs (developers.cjdropshipping.cn/en/api/api2/standard/points.html):

| Endpoint | Cost |
|---|---|
| `/product/list` | 50 pts/call |
| `/product/listV2` | 50 pts/call (same cost — no savings from preferring one over the other) |
| `/product/query` | 10 pts/call |
| `/product/variant/query` | 10 pts/call |
| `/product/getCategory`, `/product/productComments`, `/product/queryVideosByProductId` | free |

Daily allowance = 50,000 base + (last 3 months' order volume × 100), resets at 00:00 UTC,
**and also trickles back continuously** at (daily total ÷ 1440) points/minute — so "0
points remaining" doesn't necessarily mean waiting until midnight, just waiting for the
trickle to cover the next call. An earlier version of this README claimed `/product/list`
was free/0 pts — that was wrong, and a homepage that scans every leaf category at 50 pts
each is the single most expensive thing this app does. Every `CacheService` TTL below
exists to avoid re-spending points on data that hasn't changed; treat lowering one as a
real cost, not just a freshness knob. CacheService itself caps any single `cache.put()`
TTL at 6h (21600s) — there's no way to cache longer than that server-side.

## How it works

```
Browser (index.html, category.html, product.html, orders/*, disputes/*, admin/*)
   │  fetch(GAS_PROXY_URL, { action, ...payload })   — POST, text/plain body
   ▼
Google Apps Script Web App (gas-proxy/Code.gs)
   │  UrlFetchApp.fetch(...)  — CJ-Access-Token header, retries on 429
   ▼
CJ Dropshipping API (developers.cjdropshipping.com/api2.0/v1)
```

- **The CJ API key lives only in `Code.gs`**, server-side. The browser never sees it
  for any storefront-critical call (categories, products, product detail, freight,
  order create/track).
- **POST bodies are sent as `text/plain`**, not `application/json` — Apps Script web
  apps don't answer CORS preflight (OPTIONS) requests, so a JSON content-type causes a
  silent "Failed to fetch" even when the deployment itself is fine.
- **429s are retried server-side** with exponential backoff (1s/2s/4s) in
  `fetchWithRetry_` — a 429 means CJ rejected the request before processing it, so
  retrying is safe (no risk of a duplicate order).
- **The homepage's full category scan runs once, server-side, and is cached for 6h**
  (`fetchHomepageCategories_`, action `homepage_categories`). Earlier versions had the
  browser fire one live request per leaf category on every page load (50 pts each),
  which is what tripped CJ's rate limit and burned the whole daily point budget in a
  handful of loads. If the scan runs out of points partway through, it now stops
  immediately (further calls would fail identically), caches whatever it found so far
  with a short 15-minute TTL, and retries the rest sooner rather than waiting the full 6h.
- **Categories, products, and product detail try the proxy first, then fall back to
  calling CJ directly from the browser** if the proxy call throws (`withFallback_` in
  `cj-api.js`) — a broken/stale/misconfigured Apps Script deployment, or a CORS/network
  failure reaching it, no longer takes the whole storefront down. **Exception:** if the
  proxy failure is CJ saying "Insufficient API points", the direct fallback is skipped
  entirely — it shares the exact same account quota and would fail identically, so
  retrying it would only waste more of the trickle-replenished budget. The direct
  fallback (when it does run) re-authenticates with CJ itself, skips the proxy's
  server-side cache, and paces its own homepage category scan more slowly (24-category
  cap, 600ms between calls, stops early on quota exhaustion too). Every call logs which
  path served it — see **Debugging** below.

## Browsing & shopping flow

- **`categories.html`** (new) lists every category and subcategory as an expandable,
  searchable tree — the homepage only shows categories with confirmed in-stock
  products, this page shows the full catalog structure. It's free: it just re-renders
  the already-cached category tree from `CJ.getCategory()`, no per-category product
  calls.
- **`category.html`** loads 12 products per page via the free-to-render (but
  50-pt-per-call) `/product/list`, and now combines **both** an explicit "Load More"
  button and animated scroll-triggered auto-loading (`IntersectionObserver` on a
  sentinel below the grid) — newly appended cards fade/slide in. Both mechanisms share
  one guarded `loadNextPage()` so they can't fire overlapping requests against the same
  50-pt-per-call endpoint.
- **`product.html`** shows title, price, description, an image gallery with thumbnails
  (`productImageSet`, per CJ's docs), stock (summed from `product.variants[].inventories[]`,
  also per CJ's docs — not a flat field), and an embedded video **if** CJ's dedicated
  `product/queryVideosByProductId` endpoint (free, POST) returns one — video is not a
  reliable field on `product/query` itself, it only appears there under a special
  request flag and returns video IDs rather than a playable URL. If no video/gallery
  data comes back, that block is simply omitted, never fabricated.
- **"Buy Now"** goes straight to `orders/create.html?pid=&qty=&direct=1`, which fetches
  the product summary and renders it as an order-ready summary card — no manual
  PID/VID entry needed, since `Code.gs`'s `resolveVid_` already resolves a `pid` to its
  variant server-side.
- **"Add to Cart"** (`assets/js/cart.js`) is a real localStorage-backed multi-item cart,
  not a second button that does the same thing as Buy Now — items persist across pages,
  the header cart icon shows a live count, and the cart icon links to
  `orders/create.html?fromCart=1`, which renders every item with a quantity stepper and
  remove button and submits them all as one multi-line order (`createOrderV3` already
  accepts a `products` array).
- If neither a `pid` nor a cart is present, `orders/create.html` falls back to the
  original manual PID/VID/quantity fields, so ad-hoc/manual order testing still works.

## Current deployment

| | |
|---|---|
| Web app URL | `https://script.google.com/macros/s/AKfycbzJ_FElaZLMqBAhs5gpzP_xGYLyu2fe5iZomP6YGMgCSt7GmOlgFTSJ5X-XJOFc20IL/exec` |
| Deployment version | 1 (8 Jul 2026, 14:19) — same deployment ID reported again after the point-exhaustion incident below; if you redeploy, update the URL here and in `cj-api.js` |
| Configured in | `assets/js/cj-api.js` → `GAS_PROXY_URL` |

**Point-exhaustion incident (8 Jul 2026):** the account hit "Used today: ~74,580,
Remaining: 0, Required: 50" on `/product/list` — a hard account-level quota stop, not a
code bug. It was very likely caused by this app's pre-fix per-visitor homepage category
fan-out (see above) running repeatedly across today's testing/redeploys, at 50 pts/leaf
category per cold-cache scan. A separate `net::ERR_FAILED` / CORS error calling the
`/exec` URL was also observed around the same time — most likely Apps Script's own
daily quota (e.g. URL Fetch calls/day) being strained by the same historical overuse,
since a normal successful Apps Script web app response is CORS-permissive by design.
Check the Apps Script project's **Executions** log for the actual error if it recurs.
Both should recover as CJ's points trickle back (~roughly total-daily-points ÷ 1440 per
minute) or reset at 00:00 UTC.

**If you redeploy `Code.gs` as a new version, the `/exec` URL usually changes** —
update `GAS_PROXY_URL` in `assets/js/cj-api.js` to match, otherwise the storefront
keeps talking to the old (stale) deployment.

## Deploying a change to `Code.gs`

1. Open your Apps Script project → paste the full contents of `gas-proxy/Code.gs`
   over the existing `Code.gs`, replacing it entirely.
2. **Deploy → Manage deployments → Edit (pencil icon) → Version: New version → Deploy.**
3. Copy the resulting Web app URL into `assets/js/cj-api.js`'s `GAS_PROXY_URL` if it
   changed.
4. Hard-refresh the storefront (cached JSON responses from `CacheService` persist
   server-side for up to 6h regardless of client-side cache/reload).

## File map

| Path | Purpose |
|---|---|
| `index.html` | Homepage — category sections populated from one cached `homepage_categories` call |
| `categories.html` | Full category/subcategory tree, expandable + searchable (free — reuses the cached tree) |
| `category.html` | 12/page product grid, "Load More" button + animated scroll auto-load (`product/list`) |
| `product.html` | Product detail: `product/query`, `product/variant/query`, `product/productComments`, `product/queryVideosByProductId`, freight |
| `orders/index.html` | Order list + live balance (`shopping/order/list`, `shopping/pay/getBalance`) |
| `orders/detail.html` | Confirm / delete / dispute-link (`getOrderDetail`, `confirmOrder`, `deleteOrder`) |
| `orders/create.html` | New order form + freight calculator |
| `orders/track.html` | Shipment tracking (`logistic/getTrackInfo`) |
| `disputes/index.html` | Dispute list + cancel |
| `disputes/create.html` | File a dispute against an order |
| `admin/webhooks.html` | Webhook settings + product subscribe/unsubscribe |
| `admin/inventory.html` | Stock lookup by SKU/VID/PID + private-warehouse SPU overview |
| `admin/vendors.html` | Connected shops, vendors, delivery profiles |
| `admin/settings.html` | Balance, account settings, country coverage |
| `assets/js/cj-api.js` | Every CJ endpoint wrapped; proxy-backed calls try the proxy then fall back direct-to-CJ, admin-only calls are direct-to-CJ |
| `assets/js/cart.js` | localStorage-backed multi-item cart (`Cart.add/remove/updateQuantity/clear/count/get`) |
| `assets/js/layout.js` | Shared header (incl. cart badge) + sitemap footer + `showToast()`, injected on every page |
| `assets/css/theme.css` | Shared design system |
| `gas-proxy/Code.gs` | The Apps Script source — copy/paste into your Apps Script project (not auto-deployed from this repo) |

## Caching (Apps Script `CacheService`)

| Cache key | TTL | What it holds |
|---|---|---|
| `cj_categories` | 6h (CacheService max) | Full category tree — free endpoint, but this listing is also what `categories.html` and the homepage scan are built on |
| `cj_homepage_categories` | 6h normally, 15min if a scan stopped early on quota exhaustion | Aggregated "categories with in-stock products" for the homepage |
| `cj_products_<categoryId>_<page>_<size>` | 2h | Product list per category/page — 50 pts/call, so this is deliberately long |
| `cj_videos_<pid>` | 6h | Product videos — free endpoint, cached mainly to cut latency |
| `vid_<pid>` | 6h | Resolved variant ID for a product ID |
| `cj_access_token` (PropertiesService) | 23h | CJ access token |

## Debugging

Every category/product call logs to the console (`console.debug`/`console.warn`/
`console.error`, prefixed `[CJ debug]`) — open DevTools with the Console level set to
"Verbose" (Chrome hides `console.debug` under the default "Info" filter) to see it:

- `[CJ debug] → <action>` / `← <action>` — every proxy request/response, from `proxyCall`.
- `[CJ debug] <label>: proxy OK` / `proxy failed (...) — trying direct-to-CJ` /
  `direct OK` / `both proxy and direct failed` — from `withFallback_`, shows exactly
  which path (proxy vs. direct) served each `getCategory` / `getHomepageCategories` /
  `listProducts` / `queryProducts` call, and why it fell back if it did.
- Page-level logs in `index.html`, `category.html`, and `product.html` print the raw
  response and the extracted list/product alongside the `source` (`"proxy"` or
  `"direct"`) that produced it.

If products still don't show after checking the console: an empty `data` array with
`source: "proxy"` means CJ itself returned no products for that category (or the
proxy's cache is stale — wait out the TTL or clear `CacheService` by redeploying);
`source: "direct"` means the proxy failed first (check the `proxy failed (...)` log
line for why — wrong `GAS_PROXY_URL`, expired Apps Script deployment, CORS/network
failure, etc.); and `both proxy and direct failed` (or a single "CJ account is out of
API points" error with no direct attempt at all) means CJ itself is rejecting the
request — check the error text for "Insufficient API points" specifically, since that
one is an account-level quota stop that no retry or redeploy will fix (see **API
points** above).

## Known limitations

- **Admin/back-office pages call CJ directly from the browser** (`assets/js/cj-api.js`,
  "Direct-to-CJ fallback" section) — the CJ API key is visible in that file's source.
  These are lower-traffic, internal-use pages, but if this platform is ever exposed
  publicly, route them through the proxy too before that happens.
- CJ's rate limit is tied to the API key/account as a whole, not per-caller — testing
  directly against `developers.cjdropshipping.com` (e.g. via CJ's own API console)
  shares the same budget as this app's traffic and can trigger 429s independently of
  anything in this repo.
