# CJ Globally — API Reference & Status

Every API call the storefront/back-office makes goes through the `CJ` object in
[`assets/js/cj-api.js`](assets/js/cj-api.js). This file catalogs every method, which
transport it uses, its CJ point cost, which page(s) call it, and its current known
status. See [`README.md`](README.md) for the overall architecture and point-budget
rules — this file is the per-endpoint audit trail.

Legend:
- **Proxy+fallback** — tries the Google Apps Script proxy (`gas-proxy/Code.gs`) first,
  falls back to calling CJ directly from the browser only if the proxy itself errors
  (not if CJ says "insufficient points" — see README).
- **Direct-only** — always calls CJ directly from the browser. The CJ API key is
  embedded in `cj-api.js` for these, so they are only safe for low-traffic/internal
  pages (see "Known limitations" in README).

## Proxy-backed (storefront-critical)

| Method | GAS action | CJ endpoint | Cost | Used by | Status |
|---|---|---|---|---|---|
| `getCategory()` | `categories` | `/product/getCategory` | free | `categories.html`, homepage scan | OK |
| `getHomepageCategories()` | `homepage_categories` | (scans `/product/list` per leaf, cached 6h) | 50 pts/leaf on cold cache | `index.html` | OK — server-side cache prevents per-visitor refetch |
| `listProducts({categoryId,pageNum,pageSize})` | `products` | `/product/list` | 50 pts/call | `category.html` | **Fixed 2026-07-08**: a `result:false` response (e.g. quota exhausted) used to be silently treated as "0 products in this category" (misleading empty state). Now throws and shows the real "Unable to load products / Retry" banner. |
| `queryProducts({pid})` | `product_detail` | `/product/query` | 10 pts/call | `product.html` | **Fixed 2026-07-08**: a `result:false` response used to render a fake "$0 Untitled Product" page with working Buy/Add-to-Cart buttons instead of an error. Now throws and shows the error/retry state. |
| `getProductVideos(pid)` | `product_videos` | `/product/queryVideosByProductId` | free | `product.html` | **Fixed 2026-07-08**: CJ returns `result:false, message:"success"` (not an error) for products with no video — this was being logged/treated as a real failure and triggering a wasted direct-fallback attempt. Now treated as an empty result. |
| `freightCalculate(payload)` | `freight` | `/logistic/freightCalculate` | — | `orders/create.html` | No proxy fallback (proxy-only) — see **Open items** below |
| `createOrderV3(payload)` | `create_order` | `/shopping/order/createOrderV3` | — | `orders/create.html` | No proxy fallback (proxy-only) — see **Open items** below |
| `getTrackInfo(trackingNumber)` | `track` | `/logistic/getTrackInfo` | — | `orders/track.html` | No proxy fallback (proxy-only) |

## Direct-to-CJ only (admin/back-office — not proxied)

The CJ API key is visible client-side in `cj-api.js` for every method below (see
README "Known limitations"). These also lack the `withFallback_`/quota-exhaustion
short-circuit that the proxy-backed calls have, so on a quota-exhausted day they will
still attempt a doomed request (wasted trickle-replenished budget, extra console noise)
rather than failing fast.

| Method | CJ endpoint | Cost | Used by |
|---|---|---|---|
| `queryVariants(pid)` | `/product/variant/query` | 10 pts/call | `product.html` (size/color chips) |
| `productComments(params)` | `/product/productComments` | free | `product.html` (reviews) |
| `getPlatformCategoryTree()` | `/product/listed/getPlatformCategoryTree` | — | unused |
| `listV2(params)` | `/product/listV2` | 50 pts/call | reference only (same cost as `/product/list`) |
| `queryProductsByImage(imageUrl)` | `/product/queryProductsByImage` | — | unused |
| `listedByPids(pids)` | `/product/listed/listedByPids` | — | unused |
| `queryVendors(params)` | `/product/listed/queryVendors` | — | `admin/vendors.html` |
| `queryDeliveryProfiles(params)` | `/product/listed/queryDeliveryProfiles` | — | `admin/vendors.html` |
| `getReceiverCountryInfo()` | `/product/listed/getReceiverCountryInfo` | — | unused |
| `queryVariantByVid(vid)` | `/product/variant/queryByVid` | — | unused |
| `comments(params)` | `/product/comments` | — | unused |
| `sourcingQuery(params)` / `sourcingCreate(payload)` | `/product/sourcing/*` | — | unused |
| `stockQueryBySku(sku)` / `stockQueryByVid(vid)` / `getInventoryByPid(pid)` | `/product/stock/*` | — | `admin/inventory.html` |
| `privateInventory*` (5 methods) | `/product/stock/privateInventory/*` | — | `admin/inventory.html` |
| `freightCalculateTip(payload)` / `partnerFreightCalculate(payload)` | `/logistic/*` | — | unused |
| `trackInfo(params)` | `/logistic/trackInfo` | — | unused (superseded by proxied `getTrackInfo`) |
| `getSupplierLogisticsTemplate(params)` | `/logistic/getSupplierLogisticsTemplate` | — | unused |
| `orderList(params)` | `/shopping/order/list` | — | `orders/index.html` |
| `getOrderDetail(orderId)` | `/shopping/order/getOrderDetail` | — | `orders/detail.html` |
| `createOrderV2(payload)` | `/shopping/order/createOrderV2` | — | unused (superseded by proxied `createOrderV3`) |
| `confirmOrder(orderId)` / `deleteOrder(orderId)` | `/shopping/order/*` | — | `orders/detail.html` |
| `getBalance()` / `payBalance(payload)` | `/shopping/pay/*` | — | `orders/index.html`, `admin/settings.html` |
| `getDisputeList(params)` / `disputeProducts(orderId)` / `disputeConfirmInfo(disputeId)` / `createDispute(payload)` / `cancelDispute(disputeId)` | `/disputes/*` | — | `disputes/*.html` |
| `webhookSettingList()` / `webhookProductSubscribe(payload)` / `webhookProductSubscribeList()` / `webhookProductUnsubscribe(payload)` | `/webhook/*` | — | `admin/webhooks.html` |
| `getShops()` | `/shop/getShops` | — | `admin/vendors.html` |
| `getSetting()` | `/setting/get` | — | `admin/settings.html` |
| `platformApiCall(payload)` | `/platform/api/call` | — | unused |
| `syncStorehouseVideoRequests(payload)` | `/storehouseCenterWeb/syncStorehouseVideoRequests` | — | unused |

*("Cost" left blank above where CJ's points page doesn't list the endpoint and it
hasn't been observed directly — don't assume free.)*

## Fixes applied 2026-07-08

Three related bugs, all the same root cause: a CJ call resolving to `{result: false}`
(quota exhaustion, or a non-error CJ quirk) was being treated as if it had succeeded,
because the calling page never checked `.result` before rendering:

1. **`category.html`** — quota-exhausted `listProducts()` rendered "No products found in
   this category" (implying empty inventory) instead of an error. Fixed: `loadPage()`
   now throws on `!data.result`, surfacing the real "Unable to load products / Retry" UI.
2. **`product.html`** — quota-exhausted `queryProducts()` rendered a fake product page
   ("Untitled Product", $0, placeholder image, working checkout buttons) instead of an
   error. Fixed: throws on `!detailRes.result` before building the page.
3. **`getProductVideos`** — CJ returns `result:false, message:"success"` for products
   with no video, which both the proxy (`Code.gs`) and the direct fallback treated as a
   real error, logging "both proxy and direct failed" and wasting a doomed direct
   retry. Fixed: that specific message is now recognized as "no video" (empty result),
   not a failure.

Also fixed: `getAccessTokenDirect_()` (used by direct-to-CJ calls) reset its token on
every page navigation and had no de-duplication for concurrent callers, so
`product.html`'s parallel `queryVariants`/`productComments` calls could fire duplicate
`POST /authentication/getAccessToken` requests, and every category→product browse
re-authenticated from scratch — both contributing to the 429s seen on that endpoint.
Fixed: concurrent callers now share one in-flight token request, and the token is
cached in `sessionStorage` so it survives navigation for the rest of the browsing session.

## Site-wide audit (2026-07-08) — same bug, every direct-to-CJ admin/order call site

`freightCalculate`, `createOrderV3`, `getTrackInfo` were checked and are fine as-is:
they're proxy-only, `proxyCall()` throws on any failure, and there is no `result:false`
state to fall through — a plain `try/catch` at the call site is the correct, sufficient
handling, and `orders/create.html` / `orders/track.html` already do that for these three.

Everything else that calls a "direct-to-CJ admin" method (`get()`/`post()` wrappers
around `authedFetch`, see table above) had the *same* bug as the two fixed in
`category.html`/`product.html`: `authedFetch` only throws on an HTTP-level failure, so
a CJ response like `{result:false, message:"..."}` on a 200 OK response passed straight
through unchecked. Every one of the following call sites now checks `.result` and
throws with the real message before using the response, instead of silently rendering
a fake success state:

| File | Call sites fixed | What was wrong before |
|---|---|---|
| `orders/create.html` | `queryProducts` (order summary) | Failed lookup silently built a checkout line item titled with the raw `pid` at **$0**, which could then be submitted as a real order. |
| `orders/detail.html` | `getOrderDetail`, `confirmOrder`, `deleteOrder` | Failed detail fetch rendered a blank-looking but "valid" order card. **`confirmOrder`/`deleteOrder` alerted "Order confirmed."/"Order deleted." even when CJ rejected the request** — a false success claim on a state-changing action. |
| `orders/index.html` | `getBalance`, `orderList` | Failure showed `$0.00` balance and "No orders yet" — both indistinguishable from real empty/zero states. |
| `disputes/index.html` | `getDisputeList`, `cancelDispute` | Failure showed "No disputes on file"; a failed cancel silently reloaded the list with no error. |
| `disputes/create.html` | `disputeProducts`, `createDispute` | Failed lookup showed the generic "no eligible products" alert instead of the real error. **`createDispute` showed "Dispute submitted... pending review" even on failure** — a false success claim on a refund-filing action. |
| `admin/inventory.html` | `stockQueryBySku/ByVid`, `getInventoryByPid`, `privateInventorySpuPage` | Failure showed "No stock record found." / "No private inventory records found. This is expected..." — worded to look like a normal empty result. |
| `admin/settings.html` | `getBalance`, `getSetting`, `getReceiverCountryInfo` | Failure showed `$0.00`, blank email/"Standard" plan, and a bogus country count as if legitimately loaded. |
| `admin/vendors.html` | `getShops`, `queryVendors`, `queryDeliveryProfiles` | Failure showed "No connected shops found." / "No vendors returned." / "No delivery profiles configured." |
| `admin/webhooks.html` | `webhookSettingList`, `webhookProductSubscribeList`, `webhookProductSubscribe`, `webhookProductUnsubscribe` | Failure showed "No webhook endpoints configured..." / "No product subscriptions yet."; a failed subscribe/unsubscribe gave no error feedback at all. |

`orders/track.html`'s `getOrderDetail` prefill call (line ~82) was left as-is — it's
wrapped in `.catch(() => {})` purely to prefill the tracking-number field as a
convenience, and a failure there already degrades safely (the manual field still
works, no fake data is shown).

## Remaining known limitation (not fixed — architectural, larger scope)

- `queryVariants` and `productComments` are called directly from the public
  `product.html` page (not proxied), exposing the CJ API key client-side and sharing
  the same unprotected quota as everything else — see README "Known limitations". Moving
  these through the GAS proxy (new `product_variants` / `product_comments` actions in
  `Code.gs`) would close this and let them benefit from server-side caching too.
