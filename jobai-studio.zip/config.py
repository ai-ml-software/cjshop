"""Central configuration loader for JobAI Studio.

All values come from environment variables (loaded from a local .env file
if present) with sane, zero-cost defaults so the app runs out of the box
without any API keys configured.
"""
import os
from dotenv import load_dotenv

load_dotenv()

APP_NAME = os.getenv("APP_NAME", "JobAI Studio")
DB_PATH = os.getenv("DB_PATH", "sqlite:///jobai_studio.db")

# --- AI provider defaults ---
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.1:8b")

LMSTUDIO_BASE_URL = os.getenv("LMSTUDIO_BASE_URL", "http://localhost:1234/v1")
LMSTUDIO_MODEL = os.getenv("LMSTUDIO_MODEL", "local-model")

GROQ_BASE_URL = "https://api.groq.com/openai/v1"
GROQ_MODEL = "llama-3.1-70b-versatile"

GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"
GEMINI_MODEL = "gemini-1.5-flash"

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
OPENROUTER_MODEL = "meta-llama/llama-3.1-8b-instruct:free"

CEREBRAS_BASE_URL = "https://api.cerebras.ai/v1"
CEREBRAS_MODEL = "llama3.1-8b"

AI_PROVIDERS = [
    "Ollama (Local)", "LM Studio (Local)", "Groq (Cloud)",
    "Google Gemini", "OpenRouter", "Cerebras (Cloud)",
]

# --- Job search defaults ---
JSEARCH_BASE_URL = "https://jsearch.p.rapidapi.com/search"
JSEARCH_HOST = "jsearch.p.rapidapi.com"

# --- Misc ---
MAX_UPLOAD_MB = 10
AI_TIMEOUT_SECONDS = 30


def get_env(key: str, default: str = "") -> str:
    """Read an environment variable with a fallback default."""
    return os.getenv(key, default) or default
