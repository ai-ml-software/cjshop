"""Input validation helpers shared across services and UI forms."""
import re

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def validate_email(email: str):
    """Return (is_valid, error_message)."""
    if not email or not EMAIL_RE.match(email.strip()):
        return False, "Please enter a valid email address."
    return True, ""


def validate_password(password: str):
    """Return (is_valid, error_message). Min 8 chars, 1 digit, 1 special char."""
    if not password or len(password) < 8:
        return False, "Password must be at least 8 characters long."
    if not re.search(r"\d", password):
        return False, "Password must contain at least one number."
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>_\-+=\[\];'/~`]", password):
        return False, "Password must contain at least one special character."
    return True, ""


def validate_profile_input(profile_data: dict):
    """Return a list of error messages (empty list means valid)."""
    errors = []
    personal_info = profile_data.get("personal_info", {}) or {}
    if not personal_info.get("name"):
        errors.append("Full name is required.")
    if not personal_info.get("email"):
        errors.append("Email is required.")
    elif not EMAIL_RE.match(personal_info["email"].strip()):
        errors.append("Personal info email is not a valid email address.")

    skills = profile_data.get("skills") or []
    if not skills:
        errors.append("Add at least one skill.")

    prefs = profile_data.get("job_preferences", {}) or {}
    salary_min = prefs.get("salary_min")
    salary_max = prefs.get("salary_max")
    for label, value in (("salary_min", salary_min), ("salary_max", salary_max)):
        if value is not None and value != "" and not _is_positive_number(value):
            errors.append(f"{label.replace('_', ' ').title()} must be a positive number.")

    return errors


def validate_job_input(job_data: dict):
    """Return a list of error messages (empty list means valid)."""
    errors = []
    if not (job_data.get("title") or "").strip():
        errors.append("Job title is required.")
    if not (job_data.get("company") or "").strip():
        errors.append("Company name is required.")
    if not (job_data.get("description") or "").strip():
        errors.append("Job description is required.")
    return errors


def _is_positive_number(value) -> bool:
    try:
        return float(value) >= 0
    except (TypeError, ValueError):
        return False
