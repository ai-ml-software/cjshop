"""General-purpose helpers: text cleanup, rendering, dates, pagination."""
import html
import re
from datetime import datetime
from typing import Iterable, Sequence

import streamlit as st


def clean_text(text: str) -> str:
    """Collapse whitespace/newlines and strip control characters."""
    if not text:
        return ""
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def render_markdown(md_text: str) -> None:
    """Render Markdown in Streamlit, escaping raw HTML to avoid XSS."""
    if not md_text:
        st.info("Nothing to display yet.")
        return
    safe = html.escape(md_text, quote=False)
    # Re-allow Markdown syntax characters that html.escape leaves untouched;
    # Streamlit's own Markdown renderer handles the rest safely.
    st.markdown(safe, unsafe_allow_html=False)


def format_date(date_obj, fmt: str = "%b %d, %Y") -> str:
    if not date_obj:
        return ""
    if isinstance(date_obj, str):
        try:
            date_obj = datetime.fromisoformat(date_obj)
        except ValueError:
            return date_obj
    try:
        return date_obj.strftime(fmt)
    except (AttributeError, ValueError):
        return str(date_obj)


def paginate_list(items: Sequence, page: int, page_size: int = 10):
    """Return (page_items, total_pages) for a 1-indexed page number."""
    total = len(items)
    total_pages = max(1, (total + page_size - 1) // page_size)
    page = max(1, min(page, total_pages))
    start = (page - 1) * page_size
    end = start + page_size
    return items[start:end], total_pages


def get_match_score_color(score) -> str:
    try:
        score = float(score)
    except (TypeError, ValueError):
        return "gray"
    if score > 70:
        return "green"
    if score >= 40:
        return "orange"
    return "red"


def flatten_skills(jobs: Iterable) -> list:
    """Best-effort skill extraction across saved jobs' descriptions for the
    'Top matching skills' dashboard chart — naive keyword frequency, not AI."""
    common_skills = [
        "Python", "SQL", "JavaScript", "React", "AWS", "Docker", "Kubernetes",
        "Java", "C++", "Communication", "Leadership", "Agile", "Scrum",
        "Machine Learning", "Data Analysis", "Excel", "Project Management",
        "TypeScript", "Node.js", "Git", "Linux", "REST API", "CI/CD",
    ]
    counts = {}
    for job in jobs:
        desc = (getattr(job, "description", "") or "").lower()
        for skill in common_skills:
            if skill.lower() in desc:
                counts[skill] = counts.get(skill, 0) + 1
    return sorted(counts.items(), key=lambda kv: kv[1], reverse=True)
