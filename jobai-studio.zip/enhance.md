# JobAI Studio — Gap Analysis & Enhancement Plan

_Generated 2026-07-09. Snapshot of what exists, what's missing, and what this pass fixes._

## 1. Profile auto-fill (LinkedIn + CV)

| Item | Before | Gap | Status |
|---|---|---|---|
| CV upload (PDF/DOCX) | `services/cv_parser.py` extracted raw text only | Text landed in one big `base_cv_text` blob — user still had to hand-fill name, work experience, education, skills | **Fixed** — AI-structured extraction |
| LinkedIn URL | No field existed anywhere | No way to store/reference a candidate's LinkedIn profile | **Fixed** — field added |
| LinkedIn full profile scrape | N/A | LinkedIn's API needs OAuth + the rarely-granted Marketing Developer Platform product for work history; unauthenticated scraping violates ToS and gets IPs blocked. Third-party APIs (Proxycurl, Lix) have free tiers but are paid services outside this app's zero-cost design. | **Out of scope by design** — documented workaround below |

**What shipped:** `services/ai_engine.extract_structured_profile()` sends extracted CV text to the user's chosen AI provider and gets back structured JSON (personal info, work experience, education, skills, projects, certifications, languages). The Profile wizard now has an "Auto-fill with AI" step: upload a CV **or** a LinkedIn "Download your data" PDF export (Settings → Data privacy → Get a copy of your data, on linkedin.com) — both are just PDFs, so the existing PDF text extractor handles either. The structured result pre-fills every wizard field for the user to review/edit, instead of leaving a raw-text dump.

This mirrors the practical path called out in the research: **manual PDF export + parsing** is the only reliable free route to LinkedIn data; live OAuth (`r_liteprofile`) only yields name/photo/headline, not work history.

## 2. AI provider coverage

| Provider | Before | After |
|---|---|---|
| Ollama (local) | ✅ | ✅ |
| Groq | ✅ | ✅ |
| Google Gemini | ✅ | ✅ |
| OpenRouter | ✅ | ✅ |
| LM Studio (local) | ❌ missing | **Added** — same local, no-key pattern as Ollama, OpenAI-compatible endpoint (default `http://localhost:1234/v1`) |
| Cerebras | ❌ missing | **Added** — free-tier cloud inference, OpenAI-compatible endpoint, needs a free key from `cloud.cerebras.ai` |

Both are wired into `config.AI_PROVIDERS` and `services/ai_engine.get_ai_client()` using the exact same sidebar pattern as the existing providers (local = no key box, cloud = free key box with signup link).

## 3. Job sourcing

| Item | Before | Gap | Status |
|---|---|---|---|
| Single job URL paste | `job_search.add_manual_job()` / `_scrape_job_url()` | Fine for one posting at a time | Unchanged |
| Bulk company career-page scraping | Not implemented at all | The idea existed only as a note ("Hack 3's Playwright idea") — no code, no Playwright dependency, no multi-URL support | **Partially fixed** |

**What shipped:** `services/job_search.scrape_career_pages(urls)` runs the existing `requests` + BeautifulSoup scraper across a **list** of pasted URLs (one per line) and returns every successfully scraped page as a job candidate for review/save. Wired into the Job Board under "Scan company career pages (bulk)".

**What's intentionally not shipped:** a full crawler that discovers *individual job postings* from a company's `/careers` index page. Modern ATS sites (Greenhouse, Lever, Workday) render job listings via JavaScript, which `requests`/BeautifulSoup cannot execute — that needs Playwright (a ~300MB browser download) or per-ATS JSON API integrations (Greenhouse and Lever both expose public JSON endpoints, e.g. `boards-api.greenhouse.io/v1/boards/{company}/jobs`). Flagging this as a real, larger follow-up rather than faking it with a scraper that would silently return empty pages half the time.

## 4. Document library

| Item | Before | Gap | Status |
|---|---|---|---|
| Save tailored CV / cover letter | `Document` model + `crud.create_document` existed | Documents were only ever visible from inside the job they were generated for (Job Detail → Application tab) — no way to browse, re-download, or delete everything you've generated | **Fixed** |

**What shipped:** New `ui/documents.py` "My Documents" page — lists every saved document across all jobs, with type/date, a content preview, PDF/DOCX re-download, and delete. Added to the sidebar nav.

## 5. Sidebar

- Added **My Documents** to primary navigation.
- Added an **AI status line** under the nav (shows the currently active provider once one has been picked on any AI-powered page, so it's visible without re-opening the picker).
- Provider picker itself (`ai_engine.get_ai_client()`) is unchanged — it intentionally renders only on pages that need it (Job Detail, Interview Prep, and now the Profile auto-fill step), not globally, since Home/Applications/Documents have no AI calls to configure.

## 6. Explicitly not done (and why)

- **SerpAPI / Adzuna** — paid job-search APIs; excluded on purpose, app stays zero-cost by default.
- **Textkernel / Affinda / Apilayer resume parsers** — paid or freemium third-party services; the AI-structured extraction (#1) achieves the same outcome using whichever free AI provider the user already has configured, with no new external dependency or account.
- **PocketBase / Supabase** — the app's plain SQLite + bcrypt auth is simpler and already free; swapping backends is an infra decision, not a missing feature, and hasn't been requested.
- **Full LinkedIn OAuth SSO** — would only return name/photo/headline (not work history) even with `r_liteprofile`, so it wouldn't actually close the gap it's meant to close; not worth the OAuth app registration overhead for that little payoff.
- **JS-rendering career-page crawler (Playwright)** — see §3. Real value here needs per-ATS integrations (Greenhouse/Lever JSON APIs), which is a bigger, separate feature, not a drop-in fix.
