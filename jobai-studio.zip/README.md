# JobAI Studio

A free, AI-powered job search co-pilot: manage your profile, search jobs, evaluate fit, tailor your CV, generate cover letters, and practice interviews — all running on zero-cost AI providers and a local database.

## Prerequisites

- Python 3.9 or higher

## Setup

```bash
# 1. Create the project folder structure (already done if you're reading this from the repo)
cd jobai-studio

# 2. Create and activate a virtual environment
python -m venv venv
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. (Optional) Copy the environment template and add free API keys
cp .env.example .env

# 5. Run the app
streamlit run app.py
```

The app works immediately with **zero API keys** using:
- **Ollama** (local AI) — if installed and running
- **DuckDuckGo search** (job search) — no key required

## Free API Key Setup (all optional)

| Provider | Purpose | Free tier | Sign up |
|---|---|---|---|
| Ollama | Local AI, no key | Unlimited (runs on your machine) | https://ollama.com — then `ollama pull llama3.1:8b` |
| LM Studio | Local AI, no key | Unlimited (runs on your machine) | https://lmstudio.ai — start its local server, load any model |
| Groq | Cloud AI, very fast | Generous free tier | https://console.groq.com |
| Google Gemini | Cloud AI, huge context | Free tier | https://aistudio.google.com |
| OpenRouter | Cloud AI, sponsored free models | Free tier | https://openrouter.ai |
| Cerebras | Cloud AI, very fast inference | Free tier | https://cloud.cerebras.ai |
| JSearch (RapidAPI) | Structured job search | 500 requests/month free | https://rapidapi.com (subscribe to "JSearch") |

Paste any keys into `.env`, or enter them directly in the app's sidebar at runtime (session-only, never written to disk unless you add them to `.env` yourself).

## Feature Walkthrough

1. **Register** an account, then **log in**.
2. Complete your **Profile**:
   - **Auto-fill with AI** — upload your CV (PDF/DOCX) or a LinkedIn PDF export (linkedin.com → Settings & Privacy → Data privacy → Get a copy of your data) and the AI pre-fills personal info, work experience, education, skills, projects, certifications, and languages for you to review.
   - Or fill in personal info, work experience, education, skills, preferences, and your base CV by hand.
3. Go to the **Job Board**:
   - Search via DuckDuckGo or JSearch, or paste a single job URL/description manually.
   - **Scan company career pages (bulk)** — paste a list of career-page URLs (one per line) to scrape several at once. Works best on static pages; JavaScript-heavy ATS sites (Greenhouse, Lever, Workday) may come back thin.
   - Save jobs you like.
4. Open a saved job from **Saved Jobs** or the **Applications** tracker to:
   - **Evaluate Fit** — AI match score, matching/missing skills, suggestions.
   - **Tailor CV** — AI-rewritten résumé targeted at this job, downloadable as PDF/DOCX.
   - **Generate Cover Letter** — tailored, tone-adjustable, downloadable.
   - **Interview Prep** — generates tailored interview questions.
5. Track applications on the **Applications** kanban board (Saved → Applied → Interview → Offer/Rejected).
6. Practice interviews in **Interview Prep** → Mock Interview Practice: answer questions, get AI-scored feedback, and a model answer.
7. Browse everything you've generated in **My Documents** — every saved CV/cover letter in one place, re-downloadable as PDF/DOCX.
8. Check the **Home** dashboard for stats and charts on your job search progress.

## Project Structure

```
jobai_studio/
├── app.py                  # Main Streamlit entry point
├── config.py                # Config and environment loading
├── database/                # SQLAlchemy models, session mgmt, CRUD
├── services/                 # Auth, profile, job search, AI engine, CV parsing, export
├── ui/                        # One module per page, each exposing render() (incl. documents.py — "My Documents" library)
├── utils/                      # Validators and generic helpers
└── assets/style.css            # Custom theme
```

## Troubleshooting

- **Ollama not connecting**: make sure `ollama serve` is running and you've pulled a model (`ollama pull llama3.1:8b`). Check port 11434 is free.
- **LM Studio not connecting**: make sure the local server is started inside LM Studio (it defaults to port 1234) and a model is loaded.
- **AI provider rate limits**: switch providers in the sidebar (Ollama/LM Studio/Groq/Gemini/OpenRouter/Cerebras) — each has an independent free quota.
- **Job search returns no results**: try broader keywords, or use "Add a job manually" to paste a URL or description directly.
- **PDF/DOCX export fails**: usually means the AI-generated Markdown had something unusual in it — try regenerating the document.
- **"AI provider is not configured yet"**: pick a provider in the sidebar; Ollama needs no key, the others need a free key pasted into the sidebar or `.env`.

## Data Privacy

All data (profile, saved jobs, applications, documents, interview sessions) is stored locally in a SQLite file (`jobai_studio.db`) in this folder. Nothing is sent anywhere except your chosen AI provider (for AI features) and your chosen job-search provider (for search results) — both of which you control via the sidebar and `.env`.
