"""Session-based authentication: registration, login, logout.

Deliberately simple (no streamlit-authenticator dependency) so the whole
auth flow is transparent and easy to audit: passwords are hashed with
bcrypt, never stored or logged in plaintext, and the logged-in user's
identity lives only in `st.session_state`.
"""
import bcrypt
import streamlit as st
from sqlalchemy.orm import Session

from database import crud
from utils.validators import validate_email, validate_password


def _hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def _verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))
    except ValueError:
        return False


def register_user(db: Session, email: str, password: str, name: str = ""):
    """Create a new user account. Returns (user_or_none, error_message_or_none)."""
    email = (email or "").strip()
    ok, msg = validate_email(email)
    if not ok:
        return None, msg
    ok, msg = validate_password(password)
    if not ok:
        return None, msg
    if crud.get_user_by_email(db, email):
        return None, "An account with this email already exists."

    try:
        user = crud.create_user(db, email=email, hashed_password=_hash_password(password), name=name.strip())
    except ValueError as exc:
        return None, str(exc)
    return user, None


def login_user(db: Session, email: str, password: str):
    """Verify credentials and populate st.session_state on success.

    Returns (success: bool, message: str).
    """
    user = crud.get_user_by_email(db, (email or "").strip())
    if not user or not _verify_password(password or "", user.hashed_password):
        return False, "Invalid email or password."

    st.session_state["user"] = {"id": user.id, "email": user.email, "name": user.name or user.email}
    return True, "Logged in successfully."


def logout_user() -> str:
    for key in ["user", "selected_job_id", "interview_session", "ai_client", "ai_model", "ai_provider", "ai_status"]:
        st.session_state.pop(key, None)
    return "Logged out successfully."


def is_logged_in() -> bool:
    return bool(st.session_state.get("user"))


def current_user_id():
    user = st.session_state.get("user")
    return user["id"] if user else None
