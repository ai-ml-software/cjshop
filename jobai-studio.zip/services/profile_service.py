"""Profile validation, formatting-for-AI, and persistence helpers."""
from sqlalchemy.orm import Session

from database import crud
from services.cv_parser import extract_text_from_upload
from utils.validators import validate_profile_input


def parse_uploaded_cv(file) -> tuple:
    """Return (text, error)."""
    return extract_text_from_upload(file)


def format_profile_for_ai(profile) -> str:
    """Flatten a Profile ORM object into a single text block for AI prompts."""
    if not profile:
        return "No profile information available."

    info = profile.personal_info or {}
    lines = [
        f"Name: {info.get('name', '')}",
        f"Location: {info.get('location', '')}",
    ]
    if info.get("linkedin_url"):
        lines.append(f"LinkedIn: {info['linkedin_url']}")
    lines += [
        f"Summary: {info.get('summary', '')}",
        "",
        "Skills: " + ", ".join(profile.skills or []),
        "",
        "Work Experience:",
    ]
    for exp in (profile.work_experience or []):
        lines.append(
            f"- {exp.get('title', '')} at {exp.get('company', '')} "
            f"({exp.get('start', '')} - {exp.get('end', 'Present')}): {exp.get('description', '')}"
        )

    lines.append("")
    lines.append("Education:")
    for edu in (profile.education or []):
        lines.append(f"- {edu.get('degree', '')}, {edu.get('school', '')} ({edu.get('start', '')} - {edu.get('end', '')})")

    if profile.projects:
        lines.append("")
        lines.append("Projects:")
        for project in profile.projects:
            lines.append(f"- {project.get('name', '')}: {project.get('description', '')}")

    if profile.certifications:
        lines.append("")
        lines.append("Certifications: " + ", ".join(profile.certifications))

    if profile.languages:
        lines.append("Languages: " + ", ".join(profile.languages))

    prefs = profile.job_preferences or {}
    if prefs:
        lines.append("")
        lines.append(
            f"Job Preferences: roles={prefs.get('roles', '')}, industries={prefs.get('industries', '')}, "
            f"remote_ok={prefs.get('remote_ok', False)}, "
            f"salary=${prefs.get('salary_min', '?')}-${prefs.get('salary_max', '?')}"
        )

    if profile.base_cv_text:
        lines.append("")
        lines.append("Base CV (full text):")
        lines.append(profile.base_cv_text)

    return "\n".join(lines)


def apply_structured_profile(draft: dict, structured: dict, raw_cv_text: str = "") -> dict:
    """Merge AI-extracted structured CV/LinkedIn data into a profile wizard
    draft. Only overwrites a field when the extraction actually found
    something, so a partial extraction never blanks out data the user
    already entered by hand."""
    info = structured.get("personal_info") or {}
    if info:
        draft["personal_info"] = {**draft.get("personal_info", {}), **{k: v for k, v in info.items() if v}}

    for key in ("work_experience", "education", "projects"):
        value = structured.get(key) or []
        if value:
            draft[key] = value

    for key in ("skills", "certifications", "languages"):
        value = structured.get(key) or []
        if value:
            draft[key] = sorted(set(draft.get(key, [])) | set(value), key=str.lower)

    if raw_cv_text:
        draft["base_cv_text"] = raw_cv_text

    return draft


def update_user_profile(db: Session, user_id: int, form_data: dict):
    """Validate then upsert a profile. Returns (profile_or_none, errors_list)."""
    errors = validate_profile_input(form_data)
    if errors:
        return None, errors
    profile = crud.update_profile(db, user_id, **form_data)
    return profile, []
