"""Extract plain text from uploaded CV files (PDF/DOCX)."""
import docx
import pdfplumber

from config import MAX_UPLOAD_MB

MAX_BYTES = MAX_UPLOAD_MB * 1024 * 1024


def _check_size(file) -> str:
    """Return an error message if the file is too large, else empty string."""
    try:
        size = file.size
    except AttributeError:
        return ""
    if size and size > MAX_BYTES:
        return f"File is too large — please upload a file under {MAX_UPLOAD_MB}MB."
    return ""


def extract_text_from_pdf(file) -> tuple:
    """Return (text, error). error is '' on success."""
    size_error = _check_size(file)
    if size_error:
        return "", size_error
    try:
        text_parts = []
        with pdfplumber.open(file) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                text_parts.append(page_text)
        text = "\n".join(text_parts).strip()
        if not text:
            return "", "No extractable text found — the PDF may be image-based or password-protected."
        return text, ""
    except Exception as exc:  # noqa: BLE001
        return "", f"Could not read PDF: {exc}"


def extract_text_from_docx(file) -> tuple:
    """Return (text, error). error is '' on success."""
    size_error = _check_size(file)
    if size_error:
        return "", size_error
    try:
        document = docx.Document(file)
        text = "\n".join(p.text for p in document.paragraphs).strip()
        if not text:
            return "", "No extractable text found in this DOCX file."
        return text, ""
    except Exception as exc:  # noqa: BLE001
        return "", f"Could not read DOCX: {exc}"


def extract_text_from_upload(file) -> tuple:
    """Dispatch based on file extension. Return (text, error)."""
    if file is None:
        return "", "No file provided."
    name = (file.name or "").lower()
    if name.endswith(".pdf"):
        return extract_text_from_pdf(file)
    if name.endswith(".docx"):
        return extract_text_from_docx(file)
    return "", "Unsupported file type — please upload a PDF or DOCX file."
