"""Universal AI adapter + every AI-powered feature in JobAI Studio.

Supports four zero/low-cost providers behind one OpenAI-compatible
interface: local Ollama (no key), Groq, Google Gemini, and OpenRouter
(free-tier cloud keys). The app works out of the box with Ollama and
degrades gracefully — every feature function returns a clear error
dict/string instead of raising, so a flaky or unconfigured provider
never crashes the UI.
"""
import json

import streamlit as st
from openai import OpenAI, APIError, APIConnectionError, APITimeoutError

import config


def get_ai_client():
    """Render the provider picker + key input in the sidebar and return
    (client, model_name). Client is None if the provider needs a key that
    hasn't been supplied yet."""
    provider = st.sidebar.selectbox("AI Provider", config.AI_PROVIDERS, key="ai_provider")

    if provider == "Ollama (Local)":
        st.sidebar.caption("Runs 100% locally via Ollama — no API key needed. Install: ollama.com")
        client = OpenAI(base_url=config.OLLAMA_BASE_URL, api_key="ollama")
        st.session_state["ai_status"] = f"{provider} ✅"
        return client, config.OLLAMA_MODEL

    if provider == "LM Studio (Local)":
        st.sidebar.caption("Runs 100% locally via LM Studio — no API key needed. Install: lmstudio.ai, then start its local server.")
        client = OpenAI(base_url=config.LMSTUDIO_BASE_URL, api_key="lm-studio")
        st.session_state["ai_status"] = f"{provider} ✅"
        return client, config.LMSTUDIO_MODEL

    key_env_map = {
        "Groq (Cloud)": ("GROQ_API_KEY", config.GROQ_BASE_URL, config.GROQ_MODEL, "console.groq.com"),
        "Google Gemini": ("GEMINI_API_KEY", config.GEMINI_BASE_URL, config.GEMINI_MODEL, "aistudio.google.com"),
        "OpenRouter": ("OPENROUTER_API_KEY", config.OPENROUTER_BASE_URL, config.OPENROUTER_MODEL, "openrouter.ai"),
        "Cerebras (Cloud)": ("CEREBRAS_API_KEY", config.CEREBRAS_BASE_URL, config.CEREBRAS_MODEL, "cloud.cerebras.ai"),
    }
    env_key, base_url, model, signup_url = key_env_map[provider]

    api_key = st.session_state.get(f"key_{env_key}") or config.get_env(env_key)
    if not api_key:
        st.sidebar.caption(f"Free key: sign up at {signup_url}")
        entered = st.sidebar.text_input(f"{provider} API Key", type="password", key=f"input_{env_key}")
        if entered:
            st.session_state[f"key_{env_key}"] = entered
            api_key = entered

    if not api_key:
        st.session_state["ai_status"] = f"{provider} ⚠️ needs a key"
        return None, model

    client = OpenAI(base_url=base_url, api_key=api_key)
    st.session_state["ai_status"] = f"{provider} ✅"
    return client, model


def _chat(client, model: str, system_prompt: str, user_prompt: str, json_mode: bool = False):
    """Low-level call wrapper with consistent error handling and an
    AI_TIMEOUT_SECONDS-bounded request. Returns (content_or_none, error_or_none)."""
    if client is None:
        return None, "AI provider is not configured yet — pick a provider and (if needed) enter a free API key in the sidebar."

    kwargs = {}
    if json_mode:
        kwargs["response_format"] = {"type": "json_object"}

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            timeout=config.AI_TIMEOUT_SECONDS,
            **kwargs,
        )
        return response.choices[0].message.content, None
    except APITimeoutError:
        return None, "The AI provider timed out. Try again, or switch providers in the sidebar."
    except APIConnectionError:
        return None, "Could not connect to the AI provider. If using Ollama, make sure `ollama serve` is running."
    except APIError as exc:
        return None, f"AI provider returned an error: {exc}"
    except Exception as exc:  # noqa: BLE001 - final safety net, never crash the UI
        return None, f"Unexpected error calling the AI provider: {exc}"


def _safe_json(text: str, fallback: dict) -> dict:
    if not text:
        return fallback
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        # Some free models wrap JSON in markdown fences despite instructions.
        cleaned = text.strip().strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:].strip()
        try:
            return json.loads(cleaned)
        except (json.JSONDecodeError, TypeError):
            return fallback


# ---------------------------------------------------------------- Features ----
def evaluate_job_fit(client, model: str, profile_text: str, job_description: str) -> dict:
    system = (
        "You are an expert career coach and recruiter. Given a candidate profile and a job "
        "description, evaluate the fit. Respond ONLY with a JSON object with exactly these keys: "
        '"score" (integer 0-100), "matching_skills" (array of strings), '
        '"missing_skills" (array of strings), "suggestions" (string), '
        '"cultural_fit_notes" (string).'
    )
    user = f"CANDIDATE PROFILE:\n{profile_text}\n\nJOB DESCRIPTION:\n{job_description}"
    content, error = _chat(client, model, system, user, json_mode=True)
    if error:
        return {"error": error}
    return _safe_json(content, {
        "score": 0, "matching_skills": [], "missing_skills": [],
        "suggestions": "The AI response could not be parsed. Please try again.",
        "cultural_fit_notes": "",
    })


def tailor_cv(client, model: str, profile_text: str, job_description: str, options: dict) -> str:
    option_lines = []
    if options.get("quantify_achievements"):
        option_lines.append("Quantify achievements with numbers/metrics wherever plausible.")
    if options.get("use_star_method"):
        option_lines.append("Phrase experience bullets using the STAR method (Situation, Task, Action, Result).")
    if options.get("ats_optimize"):
        option_lines.append("Optimize wording and keywords for Applicant Tracking Systems (ATS).")
    option_text = " ".join(option_lines) or "Use standard best practices."

    system = (
        "You are a professional resume writer. Rewrite the candidate's base CV so it perfectly "
        "matches the target job description: prioritize relevant experience, weave in keywords "
        "from the job description naturally, remove irrelevant content, and keep a professional "
        f"tone. {option_text} Output ONLY the tailored CV in clean Markdown, keeping the same "
        "overall section structure as the original CV."
    )
    user = f"BASE CV:\n{profile_text}\n\nTARGET JOB DESCRIPTION:\n{job_description}"
    content, error = _chat(client, model, system, user)
    if error:
        return f"⚠️ {error}"
    return content or "The AI did not return any content. Please try again."


def generate_cover_letter(client, model: str, profile_text: str, job_description: str, tone: str, contact_name: str = "") -> str:
    contact_line = f"Address it to {contact_name} where appropriate." if contact_name else "Use a generic professional greeting (e.g. 'Dear Hiring Manager')."
    system = (
        f"You are an expert cover letter writer. Write a compelling, {tone} cover letter for the "
        "job described below, tailored to the candidate's background. Explain why the candidate "
        f"is a strong fit and reference specific relevant achievements. {contact_line} Output ONLY "
        "the cover letter in clean Markdown."
    )
    user = f"CANDIDATE PROFILE:\n{profile_text}\n\nJOB DESCRIPTION:\n{job_description}"
    content, error = _chat(client, model, system, user)
    if error:
        return f"⚠️ {error}"
    return content or "The AI did not return any content. Please try again."


def generate_interview_questions(client, model: str, profile_text: str, job_description: str, num_questions: int = 15) -> list:
    system = (
        f"You are an interview coach. Generate exactly {num_questions} likely interview questions "
        "for the job described below, tailored to the candidate's profile. Include a mix of "
        "technical, behavioral, and situational questions. Respond ONLY with a JSON object with "
        'key "questions": an array of objects, each with keys "type" (one of "technical", '
        '"behavioral", "situational"), "question" (string), and "suggested_answer_points" '
        "(array of short strings)."
    )
    user = f"CANDIDATE PROFILE:\n{profile_text}\n\nJOB DESCRIPTION:\n{job_description}"
    content, error = _chat(client, model, system, user, json_mode=True)
    if error:
        return [{"type": "error", "question": error, "suggested_answer_points": []}]
    parsed = _safe_json(content, {"questions": []})
    questions = parsed.get("questions", [])
    return questions if isinstance(questions, list) and questions else [
        {"type": "error", "question": "Could not generate questions — please try again.", "suggested_answer_points": []}
    ]


def evaluate_interview_answer(client, model: str, question: str, user_answer: str, profile_text: str) -> dict:
    system = (
        "You are an experienced interview coach. Evaluate the candidate's answer to the interview "
        "question. Respond ONLY with a JSON object with exactly these keys: \"score\" (integer 1-10), "
        '"strengths" (array of strings), "weaknesses" (array of strings), "model_answer" (string).'
    )
    user = (
        f"CANDIDATE PROFILE:\n{profile_text}\n\nQUESTION:\n{question}\n\n"
        f"CANDIDATE'S ANSWER:\n{user_answer}"
    )
    content, error = _chat(client, model, system, user, json_mode=True)
    if error:
        return {"error": error}
    return _safe_json(content, {
        "score": 0, "strengths": [], "weaknesses": [],
        "model_answer": "The AI response could not be parsed. Please try again.",
    })


def extract_structured_profile(client, model: str, raw_text: str) -> dict:
    """Turn raw CV/LinkedIn-export text into structured profile fields the
    Profile wizard can pre-fill. Returns a dict with an "error" key on
    failure, otherwise the same shape as the profile wizard's draft state."""
    system = (
        "You are a resume parser. Extract structured data from the resume/CV text below. "
        "Respond ONLY with a JSON object with exactly these keys: "
        '"personal_info" (object with "name", "email", "phone", "location", "summary"), '
        '"work_experience" (array of objects with "title", "company", "start", "end", "description"), '
        '"education" (array of objects with "degree", "school", "start", "end"), '
        '"skills" (array of strings), '
        '"projects" (array of objects with "name", "description", "link"), '
        '"certifications" (array of strings), '
        '"languages" (array of strings). '
        "Use \"\" or [] for anything not present in the text — never invent information. "
        "Dates should stay in whatever format the source text uses."
    )
    content, error = _chat(client, model, system, raw_text, json_mode=True)
    if error:
        return {"error": error}
    fallback = {
        "personal_info": {}, "work_experience": [], "education": [],
        "skills": [], "projects": [], "certifications": [], "languages": [],
    }
    parsed = _safe_json(content, fallback)
    for key, default in fallback.items():
        parsed.setdefault(key, default)
    return parsed
