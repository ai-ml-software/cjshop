"""Free job search: DuckDuckGo scraping, JSearch free tier, and manual entry.

Every function returns a list (or single dict for manual entry) of
standardized job dictionaries with keys: title, company, location,
job_type, salary_estimate, description, source_url, source_api.
"""
import re

import requests
from bs4 import BeautifulSoup

import config


def _standardize(title="", company="", location="", job_type="", salary_estimate="",
                  description="", source_url="", source_api="manual"):
    return {
        "title": title or "Untitled role",
        "company": company or "Unknown company",
        "location": location or "",
        "job_type": job_type or "",
        "salary_estimate": salary_estimate or "",
        "description": description or "",
        "source_url": source_url or "",
        "source_api": source_api,
    }


def search_jobs_ddg(query: str, location: str = "", limit: int = 20) -> tuple:
    """Search job boards via DuckDuckGo text search (no API key required).

    Returns (jobs_list, error_message). error_message is '' on success
    (even if the list ends up empty — that's a normal "no results").
    """
    try:
        from ddgs import DDGS
    except ImportError:
        return [], "The 'ddgs' package is not installed. Run: pip install ddgs"

    search_query = f"{query} jobs {location} site:linkedin.com/jobs OR site:indeed.com OR site:glassdoor.com".strip()
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(search_query, max_results=limit))
    except Exception as exc:  # noqa: BLE001
        return [], f"Job search failed: {exc}"

    jobs = []
    for r in results:
        title = r.get("title", "")
        body = r.get("body", "")
        href = r.get("href", "")
        company = _guess_company(title)
        jobs.append(_standardize(
            title=title, company=company, location=location,
            description=body, source_url=href, source_api="duckduckgo",
        ))
    if not jobs:
        return [], "No results found — try a broader query or use manual job entry."
    return jobs, ""


def _guess_company(title: str) -> str:
    """Best-effort company extraction from a search-result title like
    'Software Engineer - Acme Corp | LinkedIn'."""
    for sep in [" - ", " | ", " at ", " – "]:
        if sep in title:
            parts = title.split(sep)
            if len(parts) > 1:
                return parts[1].split("|")[0].strip()
    return ""


def search_jobs_jsearch(query: str, location: str = "", api_key: str = "", limit: int = 20) -> tuple:
    """Search jobs via JSearch (RapidAPI free tier: 500 req/month).

    Returns (jobs_list, error_message).
    """
    api_key = api_key or config.get_env("JSEARCH_API_KEY")
    if not api_key:
        return [], "JSearch API key not configured. Get a free key at rapidapi.com (JSearch, 500 free requests/month)."

    params = {"query": f"{query} in {location}" if location else query, "page": "1", "num_pages": "1"}
    headers = {"X-RapidAPI-Key": api_key, "X-RapidAPI-Host": config.JSEARCH_HOST}

    try:
        response = requests.get(config.JSEARCH_BASE_URL, headers=headers, params=params, timeout=15)
    except requests.RequestException as exc:
        return [], f"Network error contacting JSearch: {exc}"

    if response.status_code == 429:
        return [], "JSearch free-tier rate limit reached for this month. Try DuckDuckGo search instead."
    if response.status_code != 200:
        return [], f"JSearch returned an error (HTTP {response.status_code})."

    try:
        data = response.json()
    except ValueError:
        return [], "JSearch returned an unreadable response."

    jobs = []
    for item in (data.get("data") or [])[:limit]:
        salary = ""
        if item.get("job_min_salary") or item.get("job_max_salary"):
            salary = f"${item.get('job_min_salary', '?')} - ${item.get('job_max_salary', '?')}"
        jobs.append(_standardize(
            title=item.get("job_title", ""),
            company=item.get("employer_name", ""),
            location=item.get("job_city", "") or item.get("job_country", ""),
            job_type=item.get("job_employment_type", ""),
            salary_estimate=salary,
            description=item.get("job_description", ""),
            source_url=item.get("job_apply_link", ""),
            source_api="jsearch",
        ))
    if not jobs:
        return [], "No results found — try a broader query."
    return jobs, ""


def add_manual_job(url_or_description: str) -> tuple:
    """Accept a raw job URL (scrape it) or pasted plain text description.

    Returns (job_dict_or_none, error_message).
    """
    text = (url_or_description or "").strip()
    if not text:
        return None, "Please paste a job URL or description."

    if re.match(r"^https?://", text):
        return _scrape_job_url(text)

    # Plain pasted text — best-effort title/company guess from the first line.
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    title = lines[0] if lines else "Untitled role"
    company = lines[1] if len(lines) > 1 else ""
    return _standardize(title=title, company=company, description=text, source_api="manual"), ""


def scrape_career_pages(urls: list, limit: int = 20) -> tuple:
    """Scrape a list of pasted company career-page URLs (one job candidate
    per URL) using the same lightweight requests+BeautifulSoup approach as
    manual job entry. Returns (jobs_list, errors_list).

    This only reads static HTML — it can't execute the JavaScript that
    modern ATS platforms (Greenhouse, Lever, Workday) use to render their
    job listings, so those pages will often come back with a thin or empty
    description rather than a full listing. That needs either a headless
    browser (Playwright) or per-ATS JSON API integrations, both bigger
    follow-up features rather than something this scraper can fake.
    """
    jobs = []
    errors = []
    for raw_url in urls[:limit]:
        url = raw_url.strip()
        if not url:
            continue
        if not re.match(r"^https?://", url):
            errors.append(f"Skipped '{url}' — not a valid URL.")
            continue
        job, error = _scrape_job_url(url)
        if error:
            errors.append(f"{url}: {error}")
        else:
            jobs.append(job)
    return jobs, errors


def _scrape_job_url(url: str) -> tuple:
    try:
        response = requests.get(url, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
    except requests.RequestException as exc:
        return None, f"Could not fetch the URL: {exc}"

    if response.status_code != 200:
        return None, f"The page returned HTTP {response.status_code}."

    try:
        soup = BeautifulSoup(response.text, "html.parser")
    except Exception as exc:  # noqa: BLE001
        return None, f"Could not parse the page: {exc}"

    title_tag = soup.find("title")
    title = title_tag.get_text().strip() if title_tag else "Untitled role"

    # Grab the largest visible text block as a rough description.
    paragraphs = [p.get_text(" ", strip=True) for p in soup.find_all(["p", "li"])]
    description = "\n".join(p for p in paragraphs if len(p) > 40)[:8000]
    if not description:
        description = soup.get_text(" ", strip=True)[:8000]

    return _standardize(title=title, description=description, source_url=url, source_api="scraped"), ""
