"""Export tailored CVs / cover letters (Markdown) to PDF and DOCX."""
import re

import docx
from docx.shared import Pt
from fpdf import FPDF


def _strip_markdown_inline(text: str) -> str:
    """Remove **bold**/*italic*/`code` markers for renderers that don't
    support rich inline styling (kept simple and dependency-free)."""
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)
    text = re.sub(r"\*(.*?)\*", r"\1", text)
    text = re.sub(r"`(.*?)`", r"\1", text)
    return text


class _StyledPDF(FPDF):
    def header(self):
        self.set_font("Helvetica", "B", 14)
        self.set_text_color(37, 99, 235)  # brand blue
        self.cell(0, 10, "JobAI Studio", ln=True, align="C")
        self.ln(2)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(128, 128, 128)
        self.cell(0, 10, f"Page {self.page_no()}", align="C")


def markdown_to_pdf(md_text: str, output_path: str) -> tuple:
    """Return (output_path_or_none, error_message)."""
    if not md_text or not md_text.strip():
        return None, "Nothing to export — the document is empty."

    try:
        pdf = _StyledPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        pdf.set_font("Helvetica", size=11)

        for raw_line in md_text.splitlines():
            line = _strip_markdown_inline(raw_line.strip())
            if not line:
                pdf.ln(4)
                continue
            if raw_line.strip().startswith("# "):
                pdf.set_font("Helvetica", "B", 16)
                pdf.multi_cell(0, 8, line.lstrip("# ").strip())
                pdf.set_font("Helvetica", size=11)
            elif raw_line.strip().startswith("## "):
                pdf.set_font("Helvetica", "B", 13)
                pdf.multi_cell(0, 7, line.lstrip("# ").strip())
                pdf.set_font("Helvetica", size=11)
            elif raw_line.strip().startswith(("- ", "* ")):
                pdf.multi_cell(0, 6, f"  • {line[2:].strip()}")
            else:
                pdf.multi_cell(0, 6, line)

        pdf.output(output_path)
        return output_path, None
    except Exception as exc:  # noqa: BLE001
        return None, f"Could not generate PDF: {exc}"


def markdown_to_docx(md_text: str, output_path: str) -> tuple:
    """Return (output_path_or_none, error_message)."""
    if not md_text or not md_text.strip():
        return None, "Nothing to export — the document is empty."

    try:
        document = docx.Document()
        style = document.styles["Normal"]
        style.font.size = Pt(11)
        for section in document.sections:
            section.top_margin = section.bottom_margin = Pt(36)
            section.left_margin = section.right_margin = Pt(48)

        for raw_line in md_text.splitlines():
            line = raw_line.strip()
            if not line:
                document.add_paragraph("")
                continue
            if line.startswith("# "):
                document.add_heading(_strip_markdown_inline(line[2:]), level=1)
            elif line.startswith("## "):
                document.add_heading(_strip_markdown_inline(line[3:]), level=2)
            elif line.startswith("### "):
                document.add_heading(_strip_markdown_inline(line[4:]), level=3)
            elif line.startswith(("- ", "* ")):
                document.add_paragraph(_strip_markdown_inline(line[2:]), style="List Bullet")
            else:
                paragraph = document.add_paragraph()
                _add_bold_italic_runs(paragraph, line)

        document.save(output_path)
        return output_path, None
    except Exception as exc:  # noqa: BLE001
        return None, f"Could not generate DOCX: {exc}"


def _add_bold_italic_runs(paragraph, text: str) -> None:
    """Minimal **bold** support so DOCX output isn't fully plain-text."""
    tokens = re.split(r"(\*\*.*?\*\*)", text)
    for token in tokens:
        if token.startswith("**") and token.endswith("**"):
            run = paragraph.add_run(token[2:-2])
            run.bold = True
        else:
            paragraph.add_run(token)
