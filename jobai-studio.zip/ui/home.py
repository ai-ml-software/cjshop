"""Landing page: login/register form (logged out) or dashboard (logged in)."""
import pandas as pd
import plotly.express as px
import streamlit as st

from database import crud
from database.db import get_db
from services import auth
from utils.helpers import flatten_skills


def _render_login_register():
    st.markdown("## 💼 Welcome to JobAI Studio")
    st.caption("Your free, AI-powered job search co-pilot — evaluate fit, tailor your CV, write cover letters, and practice interviews.")

    tab_login, tab_register = st.tabs(["Log In", "Register"])

    with tab_login:
        with st.form("login_form"):
            email = st.text_input("Email", key="login_email")
            password = st.text_input("Password", type="password", key="login_password")
            submitted = st.form_submit_button("Log In", use_container_width=True)
        if submitted:
            with get_db() as db:
                success, message = auth.login_user(db, email, password)
            if success:
                st.success(message)
                st.rerun()
            else:
                st.error(message)

    with tab_register:
        with st.form("register_form"):
            name = st.text_input("Full name", key="register_name")
            email = st.text_input("Email", key="register_email")
            password = st.text_input("Password", type="password", key="register_password",
                                      help="At least 8 characters, 1 number, 1 special character.")
            submitted = st.form_submit_button("Create Account", use_container_width=True)
        if submitted:
            with get_db() as db:
                user, error = auth.register_user(db, email, password, name)
            if error:
                st.error(error)
            else:
                st.success("Account created! Please log in.")


def _stat_card(col, label: str, value):
    with col:
        st.markdown(
            f'<div class="jai-stat-card"><h2>{value}</h2><p>{label}</p></div>',
            unsafe_allow_html=True,
        )


def _render_dashboard():
    user = st.session_state["user"]
    st.markdown(f"## Welcome back, {user['name']}! 👋")

    with get_db() as db:
        jobs = crud.get_jobs_by_user_id(db, user["id"])
        applications = crud.get_applications_by_user_id(db, user["id"])
        sessions = crud.get_sessions_by_user_id(db, user["id"])

    total_saved = len(jobs)
    active_applications = len([a for a in applications if a.status not in ("rejected", "offer")])
    upcoming_interviews = len([j for j in jobs if j.status == "interview"])

    # Fit scores aren't persisted on Job directly in this schema (they're
    # computed on demand), so the average is best-effort from job notes if
    # present, otherwise shown as "N/A" rather than a fabricated number.
    scores = []
    for job in jobs:
        if job.notes and "match_score:" in (job.notes or ""):
            try:
                scores.append(float(job.notes.split("match_score:")[1].split(";")[0]))
            except (IndexError, ValueError):
                pass
    avg_score = f"{sum(scores) / len(scores):.0f}%" if scores else "N/A"

    col1, col2, col3, col4 = st.columns(4)
    _stat_card(col1, "Saved Jobs", total_saved)
    _stat_card(col2, "Active Applications", active_applications)
    _stat_card(col3, "Upcoming Interviews", upcoming_interviews)
    _stat_card(col4, "Avg. Match Score", avg_score)

    st.markdown("---")

    chart_col1, chart_col2 = st.columns(2)

    with chart_col1:
        st.markdown("#### Applications Over Time")
        if applications:
            df = pd.DataFrame([{"date": a.created_at.date() if a.created_at else None} for a in applications])
            df = df.dropna().groupby("date").size().reset_index(name="count")
            fig = px.bar(df, x="date", y="count", color_discrete_sequence=["#2563EB"])
            fig.update_layout(margin=dict(l=10, r=10, t=10, b=10), height=300)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No applications yet — save a job and add it to your tracker to see trends here.")

    with chart_col2:
        st.markdown("#### Match Score Distribution")
        if scores:
            fig = px.histogram(x=scores, nbins=10, color_discrete_sequence=["#10B981"])
            fig.update_layout(margin=dict(l=10, r=10, t=10, b=10), height=300, xaxis_title="Score", yaxis_title="Jobs")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Run 'Evaluate Fit' on a saved job to start building this chart.")

    st.markdown("#### Top Matching Skills Across Saved Jobs")
    skill_counts = flatten_skills(jobs)
    if skill_counts:
        df = pd.DataFrame(skill_counts, columns=["skill", "count"]).head(10)
        fig = px.bar(df, x="count", y="skill", orientation="h", color_discrete_sequence=["#F59E0B"])
        fig.update_layout(margin=dict(l=10, r=10, t=10, b=10), height=350, yaxis={"categoryorder": "total ascending"})
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Save some jobs to see which skills come up most often.")

    st.markdown("---")
    st.markdown("#### Quick Actions")
    qa1, qa2, qa3 = st.columns(3)
    with qa1:
        if st.button("🔍 Go to Job Board", use_container_width=True):
            st.session_state["nav"] = "Job Board"
            st.rerun()
    with qa2:
        if st.button("📝 Edit Profile", use_container_width=True):
            st.session_state["nav"] = "Profile"
            st.rerun()
    with qa3:
        if st.button("🎤 Start Interview Prep", use_container_width=True):
            st.session_state["nav"] = "Interview Prep"
            st.rerun()

    if sessions:
        st.caption(f"You've completed {len([s for s in sessions if s.completed_at])} interview practice session(s).")


def render():
    if not auth.is_logged_in():
        _render_login_register()
    else:
        _render_dashboard()
