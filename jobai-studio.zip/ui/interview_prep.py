"""Interview question generation + mock interview practice."""
from datetime import datetime

import streamlit as st

from database import crud
from database.db import get_db
from services import ai_engine
from services.auth import current_user_id
from services.profile_service import format_profile_for_ai


def _get_jobs_and_profile(user_id):
    with get_db() as db:
        jobs = crud.get_jobs_by_user_id(db, user_id)
        profile = crud.get_profile_by_user_id(db, user_id)
    return jobs, profile


def _render_question_generator(user_id, jobs, profile, client, model):
    st.markdown("### Generate Interview Questions")

    if not jobs:
        st.info("Save a job from the Job Board first so questions can be tailored to it.")
        return

    job_options = {f"{j.title} @ {j.company}": j.id for j in jobs}
    preselect_id = st.session_state.pop("interview_prep_job_id", None)
    default_index = 0
    if preselect_id:
        for i, jid in enumerate(job_options.values()):
            if jid == preselect_id:
                default_index = i
                break

    choice = st.selectbox("Job", list(job_options.keys()), index=default_index)
    num_questions = st.number_input("Number of questions", min_value=3, max_value=25, value=10)

    if st.button("Generate Questions"):
        job_id = job_options[choice]
        with get_db() as db:
            job = crud.get_job_by_id(db, job_id, user_id)
        if not profile:
            st.warning("Please complete your Profile first.")
            return
        profile_text = format_profile_for_ai(profile)
        with st.spinner("Generating interview questions..."):
            questions = ai_engine.generate_interview_questions(client, model, profile_text, job.description or "", int(num_questions))
        st.session_state["generated_questions"] = questions
        st.session_state["generated_questions_job_id"] = job_id

    questions = st.session_state.get("generated_questions")
    if questions:
        for q in questions:
            with st.expander(f"[{q.get('type', 'question').title()}] {q.get('question', '')}"):
                for point in q.get("suggested_answer_points", []):
                    st.write(f"- {point}")

        if st.button("💾 Save this question set as a session"):
            with get_db() as db:
                crud.create_session(
                    db, user_id,
                    job_id=st.session_state.get("generated_questions_job_id"),
                    questions=questions, answers=[], scores=[], feedback=[],
                )
            st.success("Session saved — start practicing in the Mock Interview tab.")

    st.markdown("---")
    st.markdown("### Past Sessions")
    with get_db() as db:
        sessions = crud.get_sessions_by_user_id(db, user_id)
    if not sessions:
        st.caption("No saved sessions yet.")
    for session in sessions:
        c1, c2, c3 = st.columns([3, 1, 1])
        label = f"Session #{session.id} — {len(session.questions or [])} questions"
        if session.overall_score is not None:
            label += f" — scored {session.overall_score:.1f}/10"
        c1.write(label)
        if c2.button("Practice", key=f"practice_{session.id}"):
            st.session_state["active_session_id"] = session.id
            st.session_state["active_question_idx"] = 0
            st.rerun()
        if c3.button("Delete", key=f"delete_session_{session.id}"):
            with get_db() as db:
                crud.delete_session(db, session.id, user_id)
            st.rerun()


def _render_mock_interview(user_id, profile, client, model):
    st.markdown("### Mock Interview Practice")

    session_id = st.session_state.get("active_session_id")
    if not session_id:
        st.info("Generate a question set and click 'Practice' in the Question Generator tab to start.")
        return

    with get_db() as db:
        session = crud.get_session_by_id(db, session_id, user_id)
    if not session or not session.questions:
        st.warning("This session has no questions.")
        return

    questions = session.questions
    idx = st.session_state.get("active_question_idx", 0)
    idx = max(0, min(idx, len(questions) - 1))
    question = questions[idx]

    st.progress((idx + 1) / len(questions))
    st.caption(f"Question {idx + 1} of {len(questions)}")
    st.markdown(f"**[{question.get('type', '').title()}]** {question.get('question', '')}")

    answer_key = f"answer_{session_id}_{idx}"
    answer = st.text_area("Your answer", key=answer_key, height=150)

    if st.button("Submit Answer", key=f"submit_{idx}"):
        if not answer.strip():
            st.warning("Please write an answer before submitting.")
        else:
            profile_text = format_profile_for_ai(profile) if profile else ""
            with st.spinner("Evaluating your answer..."):
                evaluation = ai_engine.evaluate_interview_answer(client, model, question.get("question", ""), answer, profile_text)
            st.session_state[f"eval_{session_id}_{idx}"] = evaluation

            answers = list(session.answers or [])
            scores = list(session.scores or [])
            feedback = list(session.feedback or [])
            while len(answers) <= idx:
                answers.append("")
                scores.append(0)
                feedback.append({})
            answers[idx] = answer
            scores[idx] = evaluation.get("score", 0) if not evaluation.get("error") else 0
            feedback[idx] = evaluation
            with get_db() as db:
                crud.update_session(db, session_id, user_id, answers=answers, scores=scores, feedback=feedback)

    evaluation = st.session_state.get(f"eval_{session_id}_{idx}")
    if evaluation:
        if evaluation.get("error"):
            st.error(evaluation["error"])
        else:
            st.markdown(f"**Score: {evaluation.get('score', 0)}/10**")
            c1, c2 = st.columns(2)
            with c1:
                st.markdown("**Strengths**")
                for s in evaluation.get("strengths", []):
                    st.write(f"- {s}")
            with c2:
                st.markdown("**Weaknesses**")
                for w in evaluation.get("weaknesses", []):
                    st.write(f"- {w}")
            st.markdown("**Model Answer**")
            st.write(evaluation.get("model_answer", ""))

    nav1, nav2, nav3 = st.columns(3)
    if nav1.button("← Previous", disabled=idx == 0):
        st.session_state["active_question_idx"] = idx - 1
        st.rerun()
    if nav2.button("Next →", disabled=idx == len(questions) - 1):
        st.session_state["active_question_idx"] = idx + 1
        st.rerun()
    if nav3.button("🏁 End Session"):
        with get_db() as db:
            fresh_session = crud.get_session_by_id(db, session_id, user_id)
            scores = [s for s in (fresh_session.scores or []) if s]
            overall = sum(scores) / len(scores) if scores else 0
            crud.update_session(db, session_id, user_id, overall_score=overall, completed_at=datetime.utcnow())
        st.success(f"Session complete! Overall score: {overall:.1f}/10")
        st.session_state.pop("active_session_id", None)
        st.session_state.pop("active_question_idx", None)
        st.rerun()


def render():
    st.markdown("## 🎤 Interview Preparation")
    user_id = current_user_id()
    jobs, profile = _get_jobs_and_profile(user_id)
    client, model = ai_engine.get_ai_client()

    tab_generate, tab_practice = st.tabs(["📝 Question Generator", "🎙️ Mock Interview Practice"])
    with tab_generate:
        _render_question_generator(user_id, jobs, profile, client, model)
    with tab_practice:
        _render_mock_interview(user_id, profile, client, model)
