"""Application tracker — kanban-style board across 5 statuses."""
import streamlit as st

from database import crud
from database.db import get_db
from services.auth import current_user_id

STATUSES = ["saved", "applied", "interview", "offer", "rejected"]
STATUS_LABELS = {
    "saved": "📥 Saved", "applied": "📨 Applied", "interview": "🎤 Interview",
    "offer": "🎉 Offer", "rejected": "❌ Rejected",
}


def _move_status(job_id: int, user_id: int, new_status: str):
    with get_db() as db:
        crud.update_job(db, job_id, user_id, status=new_status)


def render():
    st.markdown("## 📌 Application Tracker")
    user_id = current_user_id()

    with st.expander("➕ Add a saved job to the tracker"):
        with get_db() as db:
            all_jobs = crud.get_jobs_by_user_id(db, user_id)
        if not all_jobs:
            st.info("You have no saved jobs yet. Save some from the Job Board first.")
        else:
            options = {f"{j.title} @ {j.company}": j.id for j in all_jobs}
            choice = st.selectbox("Choose a job", list(options.keys()))
            if st.button("Add to tracker"):
                with get_db() as db:
                    crud.create_application(db, user_id, options[choice], status="saved")
                st.success("Added.")
                st.rerun()

    search = st.text_input("🔎 Filter by company or role")

    with get_db() as db:
        jobs = crud.get_jobs_by_user_id(db, user_id)

    if search:
        jobs = [j for j in jobs if search.lower() in (j.title or "").lower() or search.lower() in (j.company or "").lower()]

    if not jobs:
        st.info("No applications to show yet. Save jobs from the Job Board and add them here.")
        return

    columns = st.columns(len(STATUSES))
    for col, status in zip(columns, STATUSES):
        with col:
            st.markdown(f"#### {STATUS_LABELS[status]}")
            column_jobs = [j for j in jobs if j.status == status]
            if not column_jobs:
                st.caption("Empty")
            for job in column_jobs:
                with st.container():
                    st.markdown('<div class="jai-card">', unsafe_allow_html=True)
                    st.markdown(f"**{job.title}**")
                    st.caption(f"{job.company} · {job.saved_at.strftime('%b %d') if job.saved_at else ''}")

                    current_idx = STATUSES.index(status)
                    b1, b2 = st.columns(2)
                    if current_idx > 0:
                        if b1.button("←", key=f"left_{job.id}"):
                            _move_status(job.id, user_id, STATUSES[current_idx - 1])
                            st.rerun()
                    if current_idx < len(STATUSES) - 1:
                        target = STATUSES[current_idx + 1]
                        label = "🗑️" if target == "rejected" else "→"
                        if b2.button(label, key=f"right_{job.id}"):
                            if target == "rejected":
                                st.session_state[f"confirm_reject_{job.id}"] = True
                            else:
                                _move_status(job.id, user_id, target)
                                st.rerun()

                    if st.session_state.get(f"confirm_reject_{job.id}"):
                        st.warning("Mark as rejected?")
                        cc1, cc2 = st.columns(2)
                        if cc1.button("Yes", key=f"confirm_yes_{job.id}"):
                            _move_status(job.id, user_id, "rejected")
                            st.session_state[f"confirm_reject_{job.id}"] = False
                            st.rerun()
                        if cc2.button("No", key=f"confirm_no_{job.id}"):
                            st.session_state[f"confirm_reject_{job.id}"] = False
                            st.rerun()

                    if st.button("Open", key=f"open_{job.id}"):
                        st.session_state["selected_job_id"] = job.id
                        st.session_state["nav"] = "Job Detail"
                        st.rerun()
                    st.markdown("</div>", unsafe_allow_html=True)
