"""Single job view: AI evaluate/tailor/cover-letter/interview-prep actions."""
import tempfile

import streamlit as st

from database import crud
from database.db import get_db
from services import ai_engine, export
from services.auth import current_user_id
from services.profile_service import format_profile_for_ai
from utils.helpers import get_match_score_color


def _download_buttons(content: str, base_name: str, key_prefix: str):
    c1, c2 = st.columns(2)
    if c1.button("⬇️ Download as PDF", key=f"{key_prefix}_pdf"):
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            path, error = export.markdown_to_pdf(content, tmp.name)
        if error:
            st.error(error)
        else:
            with open(path, "rb") as f:
                st.download_button("Save PDF", f.read(), file_name=f"{base_name}.pdf", mime="application/pdf", key=f"{key_prefix}_pdf_dl")
    if c2.button("⬇️ Download as DOCX", key=f"{key_prefix}_docx"):
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as tmp:
            path, error = export.markdown_to_docx(content, tmp.name)
        if error:
            st.error(error)
        else:
            with open(path, "rb") as f:
                st.download_button(
                    "Save DOCX", f.read(), file_name=f"{base_name}.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    key=f"{key_prefix}_docx_dl",
                )


def render():
    user_id = current_user_id()
    job_id = st.session_state.get("selected_job_id")

    if not job_id:
        st.warning("No job selected. Go to the Job Board and click 'Open' on a saved job.")
        return

    with get_db() as db:
        job = crud.get_job_by_id(db, job_id, user_id)
        profile = crud.get_profile_by_user_id(db, user_id)
        documents = crud.get_documents_by_user_id(db, user_id)

    if not job:
        st.error("That job could not be found (it may have been deleted).")
        return

    if not profile:
        st.warning("Please complete your Profile first — the AI needs it to evaluate fit and tailor documents.")
        return

    profile_text = format_profile_for_ai(profile)

    st.markdown(f"## {job.title}")
    st.caption(f"{job.company} · {job.location} · {job.job_type} · {job.salary_estimate}")
    if job.source_url:
        st.markdown(f"[View original posting]({job.source_url})")
    with st.expander("Full job description", expanded=False):
        st.write(job.description or "No description available.")

    client, model = ai_engine.get_ai_client()

    st.markdown("---")
    tabs = st.tabs(["📊 Evaluate Fit", "📄 Tailor CV", "✉️ Cover Letter", "🎤 Interview Prep", "📌 Application"])

    # --- Evaluate Fit -----------------------------------------------------
    with tabs[0]:
        if st.button("Evaluate Fit", key="eval_fit_btn"):
            with st.spinner("Analyzing job fit..."):
                result = ai_engine.evaluate_job_fit(client, model, profile_text, job.description or "")
            st.session_state["last_fit_result"] = result

        result = st.session_state.get("last_fit_result")
        if result:
            if result.get("error"):
                st.error(result["error"])
            else:
                score = result.get("score", 0)
                color = get_match_score_color(score)
                st.markdown(f"### Match Score: <span class='jai-score-{color}'>{score}%</span>", unsafe_allow_html=True)
                c1, c2 = st.columns(2)
                with c1:
                    st.markdown("**✅ Matching Skills**")
                    for s in result.get("matching_skills", []) or ["None identified"]:
                        st.write(f"- {s}")
                with c2:
                    st.markdown("**⚠️ Missing Skills**")
                    for s in result.get("missing_skills", []) or ["None identified"]:
                        st.write(f"- {s}")
                st.markdown("**💡 Suggestions**")
                st.write(result.get("suggestions", ""))
                if result.get("cultural_fit_notes"):
                    st.markdown("**🤝 Cultural Fit Notes**")
                    st.write(result["cultural_fit_notes"])

                # Persist the score on the job's notes so the dashboard chart has data.
                with get_db() as db:
                    crud.update_job(db, job.id, user_id, notes=f"match_score:{score};")

    # --- Tailor CV ----------------------------------------------------------
    with tabs[1]:
        st.markdown("**Options**")
        o1, o2, o3 = st.columns(3)
        quantify = o1.checkbox("Quantify achievements", value=True)
        star = o2.checkbox("Use STAR method")
        ats = o3.checkbox("Optimize for ATS", value=True)

        if st.button("Tailor My CV", key="tailor_cv_btn"):
            with st.spinner("Tailoring your CV..."):
                tailored = ai_engine.tailor_cv(
                    client, model, profile_text, job.description or "",
                    {"quantify_achievements": quantify, "use_star_method": star, "ats_optimize": ats},
                )
            st.session_state["last_tailored_cv"] = tailored

        tailored_cv = st.session_state.get("last_tailored_cv")
        if tailored_cv:
            st.markdown(tailored_cv)
            _download_buttons(tailored_cv, f"tailored_cv_{job.company}", "cv")
            if st.button("💾 Save to Documents", key="save_cv_doc"):
                with get_db() as db:
                    crud.create_document(db, user_id, job_id=job.id, doc_type="cv", content=tailored_cv)
                st.success("Saved to your Documents.")

    # --- Cover Letter --------------------------------------------------------
    with tabs[2]:
        tone = st.selectbox("Tone", ["professional", "enthusiastic", "concise"], key="cl_tone")
        contact_name = st.text_input("Hiring manager's name (optional)", key="cl_contact")

        if st.button("Generate Cover Letter", key="gen_cl_btn"):
            with st.spinner("Writing your cover letter..."):
                letter = ai_engine.generate_cover_letter(client, model, profile_text, job.description or "", tone, contact_name)
            st.session_state["last_cover_letter"] = letter

        letter = st.session_state.get("last_cover_letter")
        if letter:
            st.markdown(letter)
            _download_buttons(letter, f"cover_letter_{job.company}", "cl")
            if st.button("💾 Save to Documents", key="save_cl_doc"):
                with get_db() as db:
                    crud.create_document(db, user_id, job_id=job.id, doc_type="cover_letter", content=letter)
                st.success("Saved to your Documents.")

    # --- Interview Prep -------------------------------------------------------
    with tabs[3]:
        st.write("Generate interview questions tailored to this job, then practice in the Interview Prep page.")
        if st.button("Generate Questions & Go to Interview Prep", key="interview_prep_btn"):
            st.session_state["interview_prep_job_id"] = job.id
            st.session_state["nav"] = "Interview Prep"
            st.rerun()

    # --- Application tracker -------------------------------------------------
    with tabs[4]:
        st.write(f"Current status: **{job.status}**")
        if st.button("📌 Add to Applications Tracker", key="add_to_apps_btn"):
            with get_db() as db:
                crud.create_application(db, user_id, job.id, status=job.status)
            st.success("Added to your Applications tracker.")

        job_docs = [d for d in documents if d.job_id == job.id]
        if job_docs:
            st.markdown("**Saved Documents for this job**")
            for doc in job_docs:
                st.write(f"- {doc.doc_type} (saved {doc.created_at.strftime('%b %d, %Y') if doc.created_at else ''})")
