"""My Documents — a library of every AI-generated CV / cover letter saved
across all jobs, since Job Detail only ever showed documents for the one
job it was opened from."""
import tempfile

import streamlit as st

from database import crud
from database.db import get_db
from services import export
from services.auth import current_user_id

DOC_TYPE_LABELS = {"cv": "📄 Tailored CV", "cover_letter": "✉️ Cover Letter"}


def _download_buttons(content: str, base_name: str, key_prefix: str):
    c1, c2 = st.columns(2)
    if c1.button("⬇️ PDF", key=f"{key_prefix}_pdf"):
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            path, error = export.markdown_to_pdf(content, tmp.name)
        if error:
            st.error(error)
        else:
            with open(path, "rb") as f:
                st.download_button("Save PDF", f.read(), file_name=f"{base_name}.pdf", mime="application/pdf", key=f"{key_prefix}_pdf_dl")
    if c2.button("⬇️ DOCX", key=f"{key_prefix}_docx"):
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as tmp:
            path, error = export.markdown_to_docx(content, tmp.name)
        if error:
            st.error(error)
        else:
            with open(path, "rb") as f:
                st.download_button(
                    "Save DOCX", f.read(), file_name=f"{base_name}.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    key=f"{key_prefix}_docx_dl",
                )


def render():
    st.markdown("## 🗂️ My Documents")
    st.caption("Every CV and cover letter you've saved from a job's detail page, in one place.")

    user_id = current_user_id()
    with get_db() as db:
        documents = crud.get_documents_by_user_id(db, user_id)
        jobs_by_id = {j.id: j for j in crud.get_jobs_by_user_id(db, user_id)}

    if not documents:
        st.info("No saved documents yet — open a saved job, generate a CV or cover letter, then click 'Save to Documents'.")
        return

    doc_type_filter = st.multiselect("Filter by type", list(DOC_TYPE_LABELS.values()))

    for doc in documents:
        label = DOC_TYPE_LABELS.get(doc.doc_type, doc.doc_type)
        if doc_type_filter and label not in doc_type_filter:
            continue

        job = jobs_by_id.get(doc.job_id)
        job_label = f"{job.title} @ {job.company}" if job else "Job no longer available"

        with st.container():
            st.markdown('<div class="jai-card">', unsafe_allow_html=True)
            st.markdown(f"**{label}** — {job_label}")
            st.caption(f"Saved {doc.created_at.strftime('%b %d, %Y') if doc.created_at else ''}")

            with st.expander("Preview"):
                st.markdown(doc.content or "_Empty document._")

            base_name = f"{doc.doc_type}_{(job.company if job else 'document')}".replace(" ", "_")
            _download_buttons(doc.content or "", base_name, f"doc_{doc.id}")

            if st.button("🗑️ Delete", key=f"delete_doc_{doc.id}"):
                with get_db() as db:
                    crud.delete_document(db, doc.id, user_id)
                st.success("Document deleted.")
                st.rerun()
            st.markdown("</div>", unsafe_allow_html=True)
