"""Multi-step profile creation/editing wizard."""
import streamlit as st

from database import crud
from database.db import get_db
from services import ai_engine
from services.auth import current_user_id
from services.profile_service import apply_structured_profile, parse_uploaded_cv, update_user_profile


def _init_wizard_state(profile):
    if "profile_wizard_step" not in st.session_state:
        st.session_state["profile_wizard_step"] = 1

    if "profile_draft" not in st.session_state:
        if profile:
            st.session_state["profile_draft"] = {
                "personal_info": profile.personal_info or {},
                "work_experience": profile.work_experience or [],
                "education": profile.education or [],
                "skills": profile.skills or [],
                "projects": profile.projects or [],
                "certifications": profile.certifications or [],
                "languages": profile.languages or [],
                "job_preferences": profile.job_preferences or {},
                "base_cv_text": profile.base_cv_text or "",
            }
        else:
            st.session_state["profile_draft"] = {
                "personal_info": {}, "work_experience": [], "education": [],
                "skills": [], "projects": [], "certifications": [], "languages": [],
                "job_preferences": {}, "base_cv_text": "",
            }


def _step_indicator(step: int):
    st.progress(step / 3)
    st.caption(f"Step {step} of 3")


def _autofill_panel():
    with st.expander("🪄 Auto-fill from CV or LinkedIn export", expanded=not st.session_state["profile_draft"]["personal_info"]):
        st.caption(
            "Upload your CV (PDF/DOCX), or a LinkedIn PDF export "
            "(linkedin.com → Settings & Privacy → Data privacy → Get a copy of your data), "
            "and the AI will pre-fill this form for you to review and edit."
        )
        client, model = ai_engine.get_ai_client()
        upload = st.file_uploader("CV or LinkedIn export (PDF/DOCX)", type=["pdf", "docx"], key="autofill_upload")

        if st.button("Auto-fill with AI", key="autofill_btn", disabled=upload is None):
            text, error = parse_uploaded_cv(upload)
            if error:
                st.error(error)
            else:
                with st.spinner("Reading your document and extracting profile data..."):
                    structured = ai_engine.extract_structured_profile(client, model, text)
                if structured.get("error"):
                    st.error(structured["error"])
                else:
                    st.session_state["profile_draft"] = apply_structured_profile(
                        st.session_state["profile_draft"], structured, raw_cv_text=text,
                    )
                    st.success("Profile pre-filled — review the fields below and adjust anything that's off.")
                    st.rerun()


def _step1_personal_info():
    draft = st.session_state["profile_draft"]
    info = draft["personal_info"]

    st.markdown("### Step 1: Personal Info")
    _autofill_panel()

    info["name"] = st.text_input("Full name", value=info.get("name", ""))
    info["email"] = st.text_input("Email", value=info.get("email", ""))
    info["phone"] = st.text_input("Phone", value=info.get("phone", ""))
    info["location"] = st.text_input("Location", value=info.get("location", ""))
    info["linkedin_url"] = st.text_input("LinkedIn profile URL", value=info.get("linkedin_url", ""), placeholder="https://www.linkedin.com/in/yourname")
    info["summary"] = st.text_area("Professional summary", value=info.get("summary", ""), height=120)

    if st.button("Next →", key="step1_next"):
        st.session_state["profile_wizard_step"] = 2
        st.rerun()


def _step2_experience_skills():
    draft = st.session_state["profile_draft"]

    st.markdown("### Step 2: Experience & Skills")

    st.markdown("#### Work Experience")
    for i, exp in enumerate(draft["work_experience"]):
        with st.expander(f"{exp.get('title', 'New role')} @ {exp.get('company', '')}", expanded=False):
            exp["title"] = st.text_input("Job title", value=exp.get("title", ""), key=f"exp_title_{i}")
            exp["company"] = st.text_input("Company", value=exp.get("company", ""), key=f"exp_company_{i}")
            c1, c2 = st.columns(2)
            exp["start"] = c1.text_input("Start date", value=exp.get("start", ""), key=f"exp_start_{i}")
            exp["end"] = c2.text_input("End date (or 'Present')", value=exp.get("end", ""), key=f"exp_end_{i}")
            exp["description"] = st.text_area("Description", value=exp.get("description", ""), key=f"exp_desc_{i}")
            if st.button("Remove this role", key=f"exp_remove_{i}"):
                draft["work_experience"].pop(i)
                st.rerun()
    if st.button("+ Add work experience"):
        draft["work_experience"].append({"title": "", "company": "", "start": "", "end": "", "description": ""})
        st.rerun()

    st.markdown("#### Education")
    for i, edu in enumerate(draft["education"]):
        with st.expander(f"{edu.get('degree', 'New entry')} — {edu.get('school', '')}", expanded=False):
            edu["degree"] = st.text_input("Degree", value=edu.get("degree", ""), key=f"edu_degree_{i}")
            edu["school"] = st.text_input("School", value=edu.get("school", ""), key=f"edu_school_{i}")
            c1, c2 = st.columns(2)
            edu["start"] = c1.text_input("Start", value=edu.get("start", ""), key=f"edu_start_{i}")
            edu["end"] = c2.text_input("End", value=edu.get("end", ""), key=f"edu_end_{i}")
            if st.button("Remove this entry", key=f"edu_remove_{i}"):
                draft["education"].pop(i)
                st.rerun()
    if st.button("+ Add education"):
        draft["education"].append({"degree": "", "school": "", "start": "", "end": ""})
        st.rerun()

    st.markdown("#### Skills")
    skills_text = st.text_input(
        "Skills (comma-separated)",
        value=", ".join(draft["skills"]),
        help="e.g. Python, SQL, Project Management",
    )
    draft["skills"] = [s.strip() for s in skills_text.split(",") if s.strip()]

    st.markdown("#### Projects")
    for i, proj in enumerate(draft["projects"]):
        with st.expander(f"{proj.get('name', 'New project')}", expanded=False):
            proj["name"] = st.text_input("Project name", value=proj.get("name", ""), key=f"proj_name_{i}")
            proj["description"] = st.text_area("Description", value=proj.get("description", ""), key=f"proj_desc_{i}")
            proj["link"] = st.text_input("Link (optional)", value=proj.get("link", ""), key=f"proj_link_{i}")
            if st.button("Remove this project", key=f"proj_remove_{i}"):
                draft["projects"].pop(i)
                st.rerun()
    if st.button("+ Add project"):
        draft["projects"].append({"name": "", "description": "", "link": ""})
        st.rerun()

    certs_text = st.text_input("Certifications (comma-separated)", value=", ".join(draft["certifications"]))
    draft["certifications"] = [c.strip() for c in certs_text.split(",") if c.strip()]

    langs_text = st.text_input("Languages (comma-separated)", value=", ".join(draft["languages"]))
    draft["languages"] = [l.strip() for l in langs_text.split(",") if l.strip()]

    c1, c2 = st.columns(2)
    if c1.button("← Back", key="step2_back"):
        st.session_state["profile_wizard_step"] = 1
        st.rerun()
    if c2.button("Next →", key="step2_next"):
        st.session_state["profile_wizard_step"] = 3
        st.rerun()


def _step3_preferences_cv():
    draft = st.session_state["profile_draft"]
    prefs = draft["job_preferences"]

    st.markdown("### Step 3: Preferences & Base CV")
    prefs["roles"] = st.text_input("Target roles (comma-separated)", value=prefs.get("roles", ""))
    prefs["industries"] = st.text_input("Target industries (comma-separated)", value=prefs.get("industries", ""))
    prefs["remote_ok"] = st.checkbox("Open to remote work", value=prefs.get("remote_ok", False))
    c1, c2 = st.columns(2)
    prefs["salary_min"] = c1.number_input("Minimum salary ($)", value=float(prefs.get("salary_min", 0) or 0), min_value=0.0, step=1000.0)
    prefs["salary_max"] = c2.number_input("Maximum salary ($)", value=float(prefs.get("salary_max", 0) or 0), min_value=0.0, step=1000.0)

    st.markdown("#### Base CV")
    upload = st.file_uploader("Upload your CV (PDF or DOCX)", type=["pdf", "docx"])
    if upload is not None:
        text, error = parse_uploaded_cv(upload)
        if error:
            st.error(error)
        else:
            draft["base_cv_text"] = text
            st.success("CV text extracted successfully.")

    draft["base_cv_text"] = st.text_area(
        "Or paste/edit your CV text directly",
        value=draft.get("base_cv_text", ""),
        height=220,
    )

    c1, c2, c3 = st.columns(3)
    if c1.button("← Back", key="step3_back"):
        st.session_state["profile_wizard_step"] = 2
        st.rerun()
    if c2.button("💾 Save Profile", key="step3_save", type="primary"):
        user_id = current_user_id()
        with get_db() as db:
            profile, errors = update_user_profile(db, user_id, draft)
        if errors:
            for e in errors:
                st.error(e)
        else:
            st.success("Profile saved!")
            for key in ["profile_wizard_step", "profile_draft"]:
                st.session_state.pop(key, None)
            st.rerun()

    if c3.button("Delete Profile", key="delete_profile"):
        st.session_state["confirm_delete_profile"] = True

    if st.session_state.get("confirm_delete_profile"):
        st.warning("Are you sure you want to delete your entire profile? This cannot be undone.")
        cc1, cc2 = st.columns(2)
        if cc1.button("Yes, delete it", key="confirm_delete_yes"):
            user_id = current_user_id()
            with get_db() as db:
                crud.delete_profile(db, user_id)
            for key in ["profile_wizard_step", "profile_draft", "confirm_delete_profile"]:
                st.session_state.pop(key, None)
            st.success("Profile deleted.")
            st.rerun()
        if cc2.button("Cancel", key="confirm_delete_no"):
            st.session_state["confirm_delete_profile"] = False
            st.rerun()


def render():
    user_id = current_user_id()
    with get_db() as db:
        profile = crud.get_profile_by_user_id(db, user_id)

    st.markdown("## 📝 Your Profile")
    _init_wizard_state(profile)

    step = st.session_state["profile_wizard_step"]
    _step_indicator(step)

    if step == 1:
        _step1_personal_info()
    elif step == 2:
        _step2_experience_skills()
    else:
        _step3_preferences_cv()
