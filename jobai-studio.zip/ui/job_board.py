"""Job search, filtering, saved jobs, and manual job entry."""
import streamlit as st

from database import crud
from database.db import get_db
from services import job_search
from services.auth import current_user_id
from utils.helpers import paginate_list
from utils.validators import validate_job_input

PAGE_SIZE = 10


def _job_card(job: dict, key_prefix: str, show_save: bool = True):
    with st.container():
        st.markdown('<div class="jai-card">', unsafe_allow_html=True)
        st.markdown(f"**{job.get('title', 'Untitled role')}**")
        st.caption(f"{job.get('company', '')} · {job.get('location', '')} · {job.get('job_type', '')}")
        snippet = (job.get("description") or "")[:220]
        st.write(snippet + ("…" if len(job.get("description") or "") > 220 else ""))
        if job.get("source_url"):
            st.markdown(f"[View original posting]({job['source_url']})")

        cols = st.columns([1, 1, 3])
        if show_save:
            if cols[0].button("🔖 Save", key=f"{key_prefix}_save"):
                errors = validate_job_input(job)
                if errors:
                    for e in errors:
                        st.error(e)
                else:
                    with get_db() as db:
                        crud.save_job(db, current_user_id(), **job)
                    st.success(f"Saved '{job['title']}'")
                    st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)


def _saved_job_card(job, key_prefix: str):
    with st.container():
        st.markdown('<div class="jai-card">', unsafe_allow_html=True)
        c1, c2 = st.columns([4, 1])
        with c1:
            st.markdown(f"**{job.title}**")
            st.caption(f"{job.company} · {job.location} · saved {job.saved_at.strftime('%b %d, %Y') if job.saved_at else ''}")
        with c2:
            new_status = st.selectbox(
                "Status", ["saved", "applied", "interview", "offer", "rejected"],
                index=["saved", "applied", "interview", "offer", "rejected"].index(job.status) if job.status in ["saved", "applied", "interview", "offer", "rejected"] else 0,
                key=f"{key_prefix}_status",
                label_visibility="collapsed",
            )
            if new_status != job.status:
                with get_db() as db:
                    crud.update_job(db, job.id, current_user_id(), status=new_status)
                st.rerun()

        b1, b2 = st.columns(2)
        if b1.button("Open", key=f"{key_prefix}_open"):
            st.session_state["selected_job_id"] = job.id
            st.session_state["nav"] = "Job Detail"
            st.rerun()
        if b2.button("🗑️ Delete", key=f"{key_prefix}_delete"):
            with get_db() as db:
                crud.delete_job(db, job.id, current_user_id())
            st.success("Job removed.")
            st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)


def render():
    st.markdown("## 🔍 Job Board")

    with st.sidebar:
        st.markdown("### Filters")
        job_type_filter = st.multiselect("Job type", ["Full-time", "Part-time", "Contract", "Remote"])
        st.selectbox("Date posted", ["Any time", "Last 24 hours", "Last week", "Last month"])
        st.slider("Min salary estimate ($k)", 0, 300, 0, step=10)

    tab_search, tab_saved = st.tabs(["🔎 Search Results", "⭐ Saved Jobs"])

    with tab_search:
        with st.form("job_search_form"):
            c1, c2, c3 = st.columns([2, 2, 1])
            query = c1.text_input("Job title / keywords", placeholder="e.g. Software Engineer")
            location = c2.text_input("Location", placeholder="e.g. Remote, New York")
            source = c3.selectbox("Source", ["DuckDuckGo (free)", "JSearch (free tier)"])
            submitted = st.form_submit_button("Search", use_container_width=True)

        with st.expander("➕ Add a job manually (paste a URL or full description)"):
            manual_input = st.text_area("Job URL or pasted description", height=100)
            if st.button("Add Job"):
                job, error = job_search.add_manual_job(manual_input)
                if error:
                    st.error(error)
                else:
                    st.session_state["manual_job_preview"] = job
                    st.success("Job parsed — review and save below.")

        if st.session_state.get("manual_job_preview"):
            _job_card(st.session_state["manual_job_preview"], key_prefix="manual_preview")

        with st.expander("🏢 Scan company career pages (bulk)"):
            st.caption(
                "Paste one career-page or job-posting URL per line. Works best on static pages — "
                "JavaScript-heavy ATS sites (Greenhouse, Lever, Workday) may come back thin."
            )
            bulk_urls = st.text_area("Career page URLs (one per line)", height=100, key="bulk_urls")
            if st.button("Scan Pages"):
                urls = [u for u in bulk_urls.splitlines() if u.strip()]
                if not urls:
                    st.warning("Paste at least one URL.")
                else:
                    with st.spinner(f"Scanning {len(urls)} page(s)..."):
                        jobs, errors = job_search.scrape_career_pages(urls)
                    st.session_state["bulk_scan_results"] = jobs
                    for e in errors:
                        st.warning(e)
                    if jobs:
                        st.success(f"Found {len(jobs)} job candidate(s) — review and save below.")

        for i, job in enumerate(st.session_state.get("bulk_scan_results", [])):
            _job_card(job, key_prefix=f"bulk_{i}")

        if submitted:
            if not query.strip():
                st.warning("Please enter a search query.")
            else:
                with st.spinner("Searching for jobs..."):
                    if source.startswith("JSearch"):
                        jobs, error = job_search.search_jobs_jsearch(query, location)
                    else:
                        jobs, error = job_search.search_jobs_ddg(query, location)
                if error and not jobs:
                    st.error(error)
                st.session_state["search_results"] = jobs
                st.session_state["search_page"] = 1

        results = st.session_state.get("search_results", [])
        if job_type_filter:
            results = [j for j in results if any(t.lower() in (j.get("job_type", "") or "").lower() for t in job_type_filter)] or results

        if results:
            page = st.session_state.get("search_page", 1)
            page_items, total_pages = paginate_list(results, page, PAGE_SIZE)
            for i, job in enumerate(page_items):
                _job_card(job, key_prefix=f"search_{page}_{i}")
            if total_pages > 1:
                new_page = st.number_input("Page", min_value=1, max_value=total_pages, value=page, key="search_page_input")
                if new_page != page:
                    st.session_state["search_page"] = new_page
                    st.rerun()
        elif "search_results" in st.session_state:
            st.info("No jobs found for that search — try different keywords or add one manually above.")

    with tab_saved:
        with get_db() as db:
            saved_jobs = crud.get_jobs_by_user_id(db, current_user_id())
        if not saved_jobs:
            st.info("You haven't saved any jobs yet — search above or add one manually.")
        else:
            for i, job in enumerate(saved_jobs):
                _saved_job_card(job, key_prefix=f"saved_{i}")
