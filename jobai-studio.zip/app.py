"""JobAI Studio — main Streamlit entry point.

Handles page config, global CSS, DB initialization, session state, and
sidebar navigation. Every page module exposes a single `render()` function.
"""
import os

import streamlit as st

from config import APP_NAME
from database.db import init_db
from services import auth
from ui import home, profile_page, job_board, job_detail, applications, interview_prep, documents

st.set_page_config(page_title=APP_NAME, layout="wide", page_icon="💼")


def _load_css():
    css_path = os.path.join(os.path.dirname(__file__), "assets", "style.css")
    try:
        with open(css_path, "r", encoding="utf-8") as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
    except FileNotFoundError:
        pass


def _init_session_state():
    st.session_state.setdefault("user", None)
    st.session_state.setdefault("selected_job_id", None)
    st.session_state.setdefault("interview_session", None)
    st.session_state.setdefault("nav", "Home")


def _init_db_once():
    if not st.session_state.get("_db_initialized"):
        try:
            init_db()
            st.session_state["_db_initialized"] = True
        except RuntimeError as exc:
            st.error(str(exc))
            st.stop()


PAGES = {
    "Home": home,
    "Profile": profile_page,
    "Job Board": job_board,
    "Job Detail": job_detail,
    "Applications": applications,
    "Interview Prep": interview_prep,
    "My Documents": documents,
}


def _sidebar_nav():
    st.sidebar.markdown(f"## 💼 {APP_NAME}")

    if auth.is_logged_in():
        user = st.session_state["user"]
        st.sidebar.caption(f"Signed in as **{user['name']}**")

        nav_options = ["Home", "Profile", "Job Board", "Applications", "Interview Prep", "My Documents"]
        current = st.session_state.get("nav", "Home")
        # "Job Detail" is reached via buttons (e.g. "Open" on a job card), not
        # this radio, so it has no matching option — default the widget's
        # highlighted option to Home in that case. `on_change` (not the return
        # value) is what actually updates `nav`, so simply re-rendering this
        # radio on an unrelated rerun never clobbers a "Job Detail" nav state.
        default_display = current if current in nav_options else "Home"

        def _apply_nav_choice():
            st.session_state["nav"] = st.session_state["nav_radio"]

        st.sidebar.radio(
            "Navigate", nav_options,
            index=nav_options.index(default_display),
            key="nav_radio",
            on_change=_apply_nav_choice,
            label_visibility="collapsed",
        )

        if st.session_state.get("ai_status"):
            st.sidebar.caption(f"AI: {st.session_state['ai_status']}")

        st.sidebar.markdown("---")
        if st.sidebar.button("🚪 Log Out", use_container_width=True):
            message = auth.logout_user()
            st.sidebar.success(message)
            st.rerun()
    else:
        st.sidebar.caption("Log in or register to get started.")
        st.session_state["nav"] = "Home"

    st.sidebar.markdown("---")


def main():
    _init_session_state()
    _load_css()
    _init_db_once()
    _sidebar_nav()

    if not auth.is_logged_in():
        home.render()
        return

    page = PAGES.get(st.session_state.get("nav", "Home"), home)
    page.render()


if __name__ == "__main__":
    main()
