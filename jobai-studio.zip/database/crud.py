"""CRUD operations for every JobAI Studio model.

Every function accepts an active SQLAlchemy `Session` as its first argument
(see `database.db.get_db`) and never leaves an unhandled exception —
integrity errors (e.g. duplicate email) are caught and surfaced as `None`
or re-raised as a `ValueError` with a friendly message, so callers in the
UI layer can show a message instead of crashing.
"""
from datetime import datetime
from typing import Optional

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from database.models import User, Profile, Job, Application, InterviewSession, Document


# ---------------------------------------------------------------- User ----
def create_user(db: Session, email: str, hashed_password: str, name: str = "") -> User:
    user = User(email=email.strip().lower(), hashed_password=hashed_password, name=name)
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise ValueError("An account with this email already exists.")
    db.refresh(user)
    return user


def get_user_by_email(db: Session, email: str) -> Optional[User]:
    return db.query(User).filter(User.email == email.strip().lower()).first()


def get_user_by_id(db: Session, user_id: int) -> Optional[User]:
    return db.query(User).filter(User.id == user_id).first()


def update_user(db: Session, user_id: int, **kwargs) -> Optional[User]:
    user = get_user_by_id(db, user_id)
    if not user:
        return None
    for key, value in kwargs.items():
        if hasattr(user, key):
            setattr(user, key, value)
    user.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(user)
    return user


def delete_user(db: Session, user_id: int) -> bool:
    user = get_user_by_id(db, user_id)
    if not user:
        return False
    db.delete(user)
    db.commit()
    return True


# ------------------------------------------------------------- Profile ----
def create_profile(db: Session, user_id: int, **profile_data) -> Profile:
    profile = Profile(user_id=user_id, **profile_data)
    db.add(profile)
    db.commit()
    db.refresh(profile)
    return profile


def get_profile_by_user_id(db: Session, user_id: int) -> Optional[Profile]:
    return db.query(Profile).filter(Profile.user_id == user_id).first()


def update_profile(db: Session, user_id: int, **profile_data) -> Profile:
    profile = get_profile_by_user_id(db, user_id)
    if not profile:
        return create_profile(db, user_id, **profile_data)
    for key, value in profile_data.items():
        if hasattr(profile, key):
            setattr(profile, key, value)
    profile.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(profile)
    return profile


def delete_profile(db: Session, user_id: int) -> bool:
    profile = get_profile_by_user_id(db, user_id)
    if not profile:
        return False
    db.delete(profile)
    db.commit()
    return True


# ------------------------------------------------------------------ Job ----
def create_job(db: Session, user_id: int, **job_data) -> Job:
    job = Job(user_id=user_id, **job_data)
    db.add(job)
    db.commit()
    db.refresh(job)
    return job


# Alias used by the job board's "save a search result" flow.
def save_job(db: Session, user_id: int, **job_data) -> Job:
    return create_job(db, user_id, **job_data)


def unsave_job(db: Session, job_id: int, user_id: int) -> bool:
    return delete_job(db, job_id, user_id)


def get_jobs_by_user_id(db: Session, user_id: int, status: Optional[str] = None):
    query = db.query(Job).filter(Job.user_id == user_id)
    if status:
        query = query.filter(Job.status == status)
    return query.order_by(Job.saved_at.desc()).all()


def get_job_by_id(db: Session, job_id: int, user_id: int) -> Optional[Job]:
    return db.query(Job).filter(Job.id == job_id, Job.user_id == user_id).first()


def update_job(db: Session, job_id: int, user_id: int, **job_data) -> Optional[Job]:
    job = get_job_by_id(db, job_id, user_id)
    if not job:
        return None
    for key, value in job_data.items():
        if hasattr(job, key):
            setattr(job, key, value)
    db.commit()
    db.refresh(job)
    return job


def delete_job(db: Session, job_id: int, user_id: int) -> bool:
    job = get_job_by_id(db, job_id, user_id)
    if not job:
        return False
    db.delete(job)
    db.commit()
    return True


# ------------------------------------------------------------ Application ----
def create_application(db: Session, user_id: int, job_id: int, **app_data) -> Application:
    application = Application(user_id=user_id, job_id=job_id, **app_data)
    db.add(application)
    db.commit()
    db.refresh(application)
    return application


def get_applications_by_user_id(db: Session, user_id: int):
    return db.query(Application).filter(Application.user_id == user_id).order_by(Application.created_at.desc()).all()


def update_application_status(db: Session, app_id: int, user_id: int, status: str) -> Optional[Application]:
    application = db.query(Application).filter(Application.id == app_id, Application.user_id == user_id).first()
    if not application:
        return None
    application.status = status
    application.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(application)
    return application


def delete_application(db: Session, app_id: int, user_id: int) -> bool:
    application = db.query(Application).filter(Application.id == app_id, Application.user_id == user_id).first()
    if not application:
        return False
    db.delete(application)
    db.commit()
    return True


# ------------------------------------------------------- InterviewSession ----
def create_session(db: Session, user_id: int, job_id: Optional[int] = None, **session_data) -> InterviewSession:
    session = InterviewSession(user_id=user_id, job_id=job_id, **session_data)
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


def get_sessions_by_user_id(db: Session, user_id: int):
    return db.query(InterviewSession).filter(InterviewSession.user_id == user_id).order_by(InterviewSession.created_at.desc()).all()


def get_session_by_id(db: Session, session_id: int, user_id: int) -> Optional[InterviewSession]:
    return db.query(InterviewSession).filter(InterviewSession.id == session_id, InterviewSession.user_id == user_id).first()


def update_session(db: Session, session_id: int, user_id: int, **session_data) -> Optional[InterviewSession]:
    session = get_session_by_id(db, session_id, user_id)
    if not session:
        return None
    for key, value in session_data.items():
        if hasattr(session, key):
            setattr(session, key, value)
    db.commit()
    db.refresh(session)
    return session


def delete_session(db: Session, session_id: int, user_id: int) -> bool:
    session = get_session_by_id(db, session_id, user_id)
    if not session:
        return False
    db.delete(session)
    db.commit()
    return True


# ------------------------------------------------------------- Document ----
def create_document(db: Session, user_id: int, job_id: Optional[int] = None, **doc_data) -> Document:
    document = Document(user_id=user_id, job_id=job_id, **doc_data)
    db.add(document)
    db.commit()
    db.refresh(document)
    return document


def get_documents_by_user_id(db: Session, user_id: int):
    return db.query(Document).filter(Document.user_id == user_id).order_by(Document.created_at.desc()).all()


def get_document_by_id(db: Session, doc_id: int, user_id: int) -> Optional[Document]:
    return db.query(Document).filter(Document.id == doc_id, Document.user_id == user_id).first()


def delete_document(db: Session, doc_id: int, user_id: int) -> bool:
    document = get_document_by_id(db, doc_id, user_id)
    if not document:
        return False
    db.delete(document)
    db.commit()
    return True
