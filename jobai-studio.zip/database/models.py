"""SQLAlchemy ORM models for JobAI Studio."""
from datetime import datetime, timezone

from sqlalchemy import (
    Column, Integer, String, Text, DateTime, ForeignKey, JSON, Float
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


def utcnow():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    name = Column(String(255), nullable=True)
    hashed_password = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)

    profile = relationship("Profile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    jobs = relationship("Job", back_populates="user", cascade="all, delete-orphan")
    applications = relationship("Application", back_populates="user", cascade="all, delete-orphan")
    interview_sessions = relationship("InterviewSession", back_populates="user", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="user", cascade="all, delete-orphan")


class Profile(Base):
    __tablename__ = "profiles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)

    personal_info = Column(JSON, default=dict)       # name, email, phone, location, summary
    work_experience = Column(JSON, default=list)      # [{title, company, start, end, description}]
    education = Column(JSON, default=list)             # [{degree, school, start, end}]
    skills = Column(JSON, default=list)                 # ["Python", "SQL", ...]
    projects = Column(JSON, default=list)               # [{name, description, link}]
    certifications = Column(JSON, default=list)
    languages = Column(JSON, default=list)
    job_preferences = Column(JSON, default=dict)        # roles, industries, remote_ok, salary_min, salary_max
    base_cv_text = Column(Text, default="")

    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)

    user = relationship("User", back_populates="profile")


class Job(Base):
    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    title = Column(String(255), nullable=False)
    company = Column(String(255), default="")
    location = Column(String(255), default="")
    job_type = Column(String(50), default="")
    salary_estimate = Column(String(100), default="")
    description = Column(Text, default="")
    source_url = Column(String(1000), default="")
    source_api = Column(String(50), default="manual")
    status = Column(String(50), default="saved")  # saved/applied/interview/offer/rejected
    notes = Column(Text, default="")
    saved_at = Column(DateTime, default=utcnow)

    user = relationship("User", back_populates="jobs")
    applications = relationship("Application", back_populates="job", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="job", cascade="all, delete-orphan")
    interview_sessions = relationship("InterviewSession", back_populates="job", cascade="all, delete-orphan")


class Application(Base):
    __tablename__ = "applications"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    status = Column(String(50), default="saved")
    applied_date = Column(DateTime, nullable=True)
    follow_up_date = Column(DateTime, nullable=True)
    notes = Column(Text, default="")

    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)

    job = relationship("Job", back_populates="applications")
    user = relationship("User", back_populates="applications")


class InterviewSession(Base):
    __tablename__ = "interview_sessions"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    questions = Column(JSON, default=list)   # [{type, question, suggested_answer_points}]
    answers = Column(JSON, default=list)      # [str, ...]
    scores = Column(JSON, default=list)        # [int, ...]
    feedback = Column(JSON, default=list)       # [{strengths, weaknesses, model_answer}]
    overall_score = Column(Float, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=utcnow)

    job = relationship("Job", back_populates="interview_sessions")
    user = relationship("User", back_populates="interview_sessions")


class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    doc_type = Column(String(50), nullable=False)  # cv / cover_letter
    content = Column(Text, default="")
    file_path = Column(String(500), default="")
    created_at = Column(DateTime, default=utcnow)

    job = relationship("Job", back_populates="documents")
    user = relationship("User", back_populates="documents")
