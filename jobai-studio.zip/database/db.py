"""Database engine, session management and initialization for JobAI Studio."""
from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from config import DB_PATH
from database.models import Base

_connect_args = {"check_same_thread": False} if DB_PATH.startswith("sqlite") else {}

engine = create_engine(DB_PATH, connect_args=_connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def init_db() -> None:
    """Create all tables if they do not already exist. Safe to call repeatedly."""
    try:
        Base.metadata.create_all(bind=engine)
    except Exception as exc:  # pragma: no cover - defensive, surfaced to the UI
        raise RuntimeError(f"Failed to initialize database: {exc}") from exc


@contextmanager
def get_db():
    """Yield a SQLAlchemy session, guaranteeing it is closed afterwards."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
